import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mochila',
  templateUrl: './mochila.component.html',
  styleUrls: ['./mochila.component.css']
})
export class MochilaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
