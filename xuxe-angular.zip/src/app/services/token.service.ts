import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  constructor() { }

  private readonly TOKEN_KEY = 'auth_token';

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY ) || 'default';
  }
  getRole(): string | null {
    return localStorage.getItem('userRole') || 'default';
  }

  setToken(token: any): void {
    localStorage.setItem(this.TOKEN_KEY, token.access_token);
    localStorage.setItem('userRole', token.role);
  }

  removeToken(): boolean {
    try {
      localStorage.removeItem(this.TOKEN_KEY);
      return true;
    } catch (error) {
      return false;
    }
  }
  removeRole(): boolean {
    try {
      localStorage.removeItem('userRole');
      return true;
    } catch (error) {
      return false;
    }
  }
}
