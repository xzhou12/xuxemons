import { ComponentFixture, TestBed } from '@angular/core/testing';

import { XuxemonsComponent } from './xuxemons.component';

describe('XuxemonsComponent', () => {
  let component: XuxemonsComponent;
  let fixture: ComponentFixture<XuxemonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ XuxemonsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(XuxemonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
