import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CrearComponent } from './xuxemons/crear/crear.component';
import { XuxemonsComponent } from './xuxemons/xuxemons.component';
import { EditComponent } from './xuxemons/edit/edit.component';
import { MochilaComponent } from './mochila/mochila.component';

const routes: Routes = [

  { path: 'error', component: ErrorComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'xuxemons', component: XuxemonsComponent},
  { path: 'xuxemons/crear', component: CrearComponent },
  { path: 'xuxemons/editar', component: EditComponent },
  { path: 'mochila', component: MochilaComponent},
  {
    path: 'error',
    redirectTo: '/error',
    pathMatch: 'full'
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/error',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
