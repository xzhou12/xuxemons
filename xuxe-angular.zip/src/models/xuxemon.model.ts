export interface Xuxemon {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  name: string;
  tipo: string;
  tamano: string;
  comidas: number;
  archivo: string;
  created_at?: string; // Optional property for created timestamp
  updated_at?: string; // Optional property for updated timestamp
}