export interface User {
    id?: number; // The question mark denotes that this property is optional, assuming it's auto-incremented.
    name: string;
    email: string;
    password: string;
    rol: 'user' | 'admin'; // Using an enum-like structure for 'rol'
    rememberToken?: string; // Optional property
    created_at?: string; // Optional property for created timestamp
    updated_at?: string; // Optional property for updated timestamp
  }