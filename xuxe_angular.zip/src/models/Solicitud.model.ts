import { User } from "./user.model";

export interface Solicitud {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  sender_id: number;
  reciver_id: number;
  offer_id: number;
  created_at: Date | null;
  updated_at: Date | null;
  offer: {
    id: number;
    name: string;
    tipo: string;
    archivo: string;
    tamano: string;
    created_at: Date | null;
    updated_at: Date | null;
  }
  sender: User;
}