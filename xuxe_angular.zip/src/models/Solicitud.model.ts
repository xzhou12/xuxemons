import { Capturados } from "./capturados.model";
import { User } from "./user.model";
import { Xuxemon } from "./xuxemon.model";

export interface Solicitud {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  sender_id: number;
  receiver_id: number;
  offer_id: number;
  r_offer_id: number;
  created_at: Date | null;
  updated_at: Date | null;
  offer: {
    id: number,
    user_id: number,
    xuxemon_id: string,
    tamano: string,
    caramelos_dados: number,
    equipado: number,
    created_at?: Date,
    updated_at?: Date
    xuxemon: Xuxemon;
  }
  sender: {
    id: number,
    name: string,
    email: string,
    id_code: string,
    rol: string,
    date_redeem: Date,
    created_at?: Date,
    updated_at?: Date
  }
  r_offer: {
    id: number,
    user_id: number,
    xuxemon_id: string,
    tamano: string,
    caramelos_dados: number,
    equipado: number,
    created_at?: Date,
    updated_at?: Date
    xuxemon: Xuxemon;
  }
  receiver: {
    id: number,
    name: string,
    email: string,
    id_code: string,
    rol: string,
    date_redeem: Date,
    created_at?: Date,
    updated_at?: Date
  };
}