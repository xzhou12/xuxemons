import { Objetos } from "./Objetos.model";

export interface Mochila {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  user_id: number;
  objetos_id: number;
  cantidad: string;
  created_at:Date|null;
  updated_at:Date|null;
  objetos: Objetos;
  cantidadInput?: number|null;
  }