export interface User {
    id?: number; // The question mark denotes that this property is optional, assuming it's auto-incremented.
    name: string;
    id_code: number;
    email: string;
    rol: 'user' | 'admin';
    rememberToken?: string; 
    created_at?: string; 
    updated_at?: string; 
  }