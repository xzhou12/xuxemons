export interface Xuxemon {
  id: number; // Assuming it's an auto-incremented field, marked as optional
  name: string;
  tipo: string;
  archivo: string;
  created_at?: string|null; // Optional property for created timestamp
  updated_at?: string|null; // Optional property for updated timestamp
}