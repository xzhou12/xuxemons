export interface Enfermedad {
  id: number; // Assuming it's an auto-incremented field, marked as optional
  enfermedad: string;
  cod_enfermedad: string;
  descripcion: string;
  porcentaje: number;
  cura: number;
  created_at:Date|null;
  updated_at:Date|null;
  }