export interface AmigoPeticion {
    id?: number; // The question mark denotes that this property is optional, assuming it's auto-incremented.
    name: string;
    email: string;
    id_code: string;
    rol: string;
    date_redeem: string;
    created_at: string | null;
    updated_at: string;
    pivot: {
      friend_id: number;
      user_id: number;
    };
  }