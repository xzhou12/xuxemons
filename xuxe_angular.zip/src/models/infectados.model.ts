export interface Infectado {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  user_id: number;
  capturados_id: number;
  enfermedad_id: number;
  created_at:Date|null;
  updated_at:Date|null;
  }