import { Xuxemon } from "./xuxemon.model";

export interface Capturados {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  user_id: number;
  xuxemon_id: number;
  tamano: string;
  caramelos_dados: number;
  created_at:Date|null;
  updated_at:Date|null;
  xuxemon: Xuxemon;
  porcentaje: number|null;
  equipado:number;
  }