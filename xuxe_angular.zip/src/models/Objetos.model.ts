export interface Objetos {
  id?: number; // Assuming it's an auto-incremented field, marked as optional
  objeto: string;
  archivo: string;
  tipo: string;
  created_at:Date|null;
  updated_at:Date|null;
  }