import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { MochilaService } from '../services/mochila.service';
import { Mochila } from 'src/models/Mochila.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userRole: String | null = this.tokenService.getRole();
  mochila: Mochila;
  constructor(private router: Router, public tokenService: TokenService, public authService: AuthService, public mochilaService: MochilaService) { }

  ngOnInit(): void {
    this.CargarCoins();
  }
  logout() {
    const confirmacion = window.confirm('¿Seguro que desea cerrar sesión?');
    if (confirmacion) {
      if (this.tokenService.removeToken() && this.authService.Logout()) {
        //si sale bien cierra sesion
        alert('Sesion cerrada correctamente.');
        this.router.navigate(['/login']);
      } else {
        //avisa de que algo ah ido mal
        alert('Error al cerrar sesion');
      }
    }

  }

  CargarCoins() {
    this.mochilaService.MochilaCoinsShow()
      .subscribe(Data => {
        this.mochila = Data[0]; // Assign the received data to the array
      });
  }

}
