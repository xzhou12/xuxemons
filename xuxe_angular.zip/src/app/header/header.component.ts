import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userRole: String | null = this.tokenService.getRole();
  constructor(private router: Router, public tokenService: TokenService) { }

  ngOnInit(): void {
  }
  logout() {
    if (this.tokenService.removeToken()&&this.tokenService.removeRole()) {
      //si sale bien cierra sesion
      this.router.navigate(['/login']);
      alert('Sesion cerrada correctamente.');
    } else {
      //avisa de que algo ah ido mal
      alert('Error al cerrar sesion');
    }
  }
}
