import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guard/guard.guard';
import { ErrorComponent } from './error/error.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CrearComponent } from './xuxemons/crear/crear.component';
import { XuxemonsComponent } from './xuxemons/xuxemons.component';
import { EditComponent } from './xuxemons/edit/edit.component';
import { MochilaComponent } from './mochila/mochila.component';
import { InventarioComponent } from './inventario/inventario.component';
import { HomeComponent } from './home/home.component';
import { ConfigComponent } from './config/config.component';
import { DeniedComponent } from './denied/denied.component';
import { HospitalComponent } from './hospital/hospital.component';
import { SocialComponent } from './social/social.component';
import { LandingComponent } from './landing/landing.component';
import { IntercambioComponent } from './intercambio/intercambio.component';

const routes: Routes = [

  { path: 'error', component: ErrorComponent },
  { path: 'landing', component: LandingComponent },
  { path: 'denied', component: DeniedComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'inventario', component: InventarioComponent, canActivate: [AuthGuard] },
  { path: 'xuxemons', component: XuxemonsComponent, canActivate: [AuthGuard] },
  { path: 'xuxemons/crear', component: CrearComponent, canActivate: [AuthGuard] },
  { path: 'xuxemons/editar', component: EditComponent, canActivate: [AuthGuard] },
  { path: 'intercambio', component: IntercambioComponent,canActivate: [AuthGuard]},
  { path: 'mochila', component: MochilaComponent, canActivate: [AuthGuard] },
  { path: 'hospital', component: HospitalComponent, canActivate: [AuthGuard] },
  { path: 'config', component: ConfigComponent, canActivate: [AuthGuard], data: { expectedRole: 'admin' } },
  { path: 'social', component: SocialComponent, canActivate: [AuthGuard] },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
  {
    path: 'error',
    redirectTo: '/error',
    pathMatch: 'full'
  },
  {
    path: '',
    redirectTo: '/landing',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/error',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
