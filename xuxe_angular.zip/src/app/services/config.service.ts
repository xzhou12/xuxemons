import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Capturados } from 'src/models/capturados.model';
import { TokenService } from './token.service';
import { Infectado } from 'src/models/infectados.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient, public tokenService: TokenService) { }

  getSize(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}settings/size`, { headers });
  }

  setSize(valor: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/size`, { valor }, { headers });
  }

  getMedium(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}settings/candy/medium`, { headers });
  }

  setMedium(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/candy/medium`, { valor }, { headers });
  }

  getBig(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}settings/candy/big`, { headers });
  }

  setBig(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/candy/big`, { valor }, { headers });
  }

  getXuxeDefault(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}settings/candy/daily`, { headers });
  }

  setXuxeDefault(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/candy/daily`, { valor }, { headers });
  }

  getXuxesBajon(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}settings/sugar_low`, { headers });
  }

  setXuxesBajon(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/sugar_low`, { valor }, { headers });
  }

  getPorcentajeEnfermedad(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}enfermedades`, { headers });
  }

  setPorcentajeEnfermedad(id_enfermedad: number | undefined, porcentaje: number | undefined): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}settings/enfermedad/percentage`, { id_enfermedad, porcentaje }, { headers });
  }

  CurarXuxemon(infectado_id:number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}admin/curar`, { infectado_id }, { headers });
  }

  
  InfectarXuxemon(enfermedad_id: number , capturados_id: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}admin/infectar`, { capturados_id, enfermedad_id  }, { headers });
  }


  CapturadosShow(): Observable<Capturados[]> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get<Capturados[]>(`${this.apiUrl}admin/capturados`, { headers });
  }

  getInfectados(): Observable<Infectado[]> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get<Infectado[]>(`${this.apiUrl}infectados`, { headers });
  }

}
