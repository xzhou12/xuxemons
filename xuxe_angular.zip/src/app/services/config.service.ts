import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Capturados } from 'src/models/capturados.model';
import { TokenService } from './token.service';
import { Infectado } from 'src/models/infectados.model';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  constructor(private http: HttpClient, public tokenService: TokenService) { }

  getSize(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/settings/size', { headers });
  }

  setSize(valor: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/size', { valor }, { headers });
  }

  getMedium(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/settings/candy/medium', { headers });
  }

  setMedium(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/candy/medium', { valor }, { headers });
  }

  getBig(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/settings/candy/big', { headers });
  }

  setBig(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/candy/big', { valor }, { headers });
  }

  getXuxeDefault(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/settings/candy/daily', { headers });
  }

  setXuxeDefault(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/candy/daily', { valor }, { headers });
  }

  getXuxesBajon(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/settings/sugar_low', { headers });
  }

  setXuxesBajon(valor: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/sugar_low', { valor }, { headers });
  }

  getPorcentajeEnfermedad(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/enfermedades', { headers });
  }

  setPorcentajeEnfermedad(id_enfermedad: number | undefined, porcentaje: number | undefined): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/settings/enfermedad/percentage', { id_enfermedad, porcentaje }, { headers });
  }

  CurarXuxemon(infectado_id:number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/admin/curar', { infectado_id }, { headers });
  }

  InfectarXuxemon(enfermedad_id: number , capturados_id: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/admin/infectar', { capturados_id, enfermedad_id  }, { headers });
  }

  CapturadosShow(): Observable<Capturados[]> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get<Capturados[]>('http://127.0.0.1:8000/api/admin/capturados', { headers });
  }

  getInfectados(): Observable<Infectado[]> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get<Infectado[]>('http://127.0.0.1:8000/api/infectados', { headers });
  }

}
