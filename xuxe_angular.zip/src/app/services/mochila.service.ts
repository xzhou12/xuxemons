import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { Mochila } from 'src/models/Mochila.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MochilaService {
  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient, public tokenService: TokenService) { }

  MochilaShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}mochila`, { headers });
  }

  MochilaCandyShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}mochila/candy`, { headers });
  }

  MochilaCoinsShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}mochila/coins`, { headers });
  }

  DebugCofre(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}mochila/candy-debug`, {}, { headers });
  }

  AbrirCofre(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}redeem/daily-candy`, {}, { headers });
  }

}
