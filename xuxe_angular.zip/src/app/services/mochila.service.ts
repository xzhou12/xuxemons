import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { Mochila } from 'src/models/Mochila.model';

@Injectable({
  providedIn: 'root'
})
export class MochilaService {

  constructor(private http: HttpClient, public tokenService: TokenService) { }

  MochilaShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/mochila', { headers });
  }

  MochilaCandyShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/mochila/candy', { headers });
  }

  MochilaCoinsShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/mochila/coins', { headers });
  }

  AbrirCofre(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post('http://127.0.0.1:8000/api/mochila/candy-debug', {}, { headers });
  }

}
