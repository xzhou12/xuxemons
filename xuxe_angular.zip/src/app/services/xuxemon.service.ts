import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { Capturados } from 'src/models/capturados.model';
import { Xuxemon } from 'src/models/xuxemon.model';

@Injectable({
  providedIn: 'root'
})
export class XuxemonService {

  constructor(private http: HttpClient, public tokenService: TokenService) {
  }

  XuxeUpdate(xuxe: any, id:any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers de actualizacion

    return this.http.put(`http://127.0.0.1:8000/api/xuxemons/${id}`, xuxe, { headers });
  }

  XuxeCreate(xuxemon: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de crear
    return this.http.post(`http://127.0.0.1:8000/api/xuxemons/`, xuxemon, { headers });
  }

  XuxeDelete(id: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de delete
    return this.http.delete(`http://127.0.0.1:8000/api/xuxemons/${id}`, { headers });
  }

  XuxeIndex(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/capturados', { headers });
  }

    //funciones de xuxemon/inventario

    XuxemonShow(): Observable<any> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });
      //peticion con headers para cargar los xuxemons capturados
      return this.http.get('http://127.0.0.1:8000/api/xuxemons', { headers });
    }

    CapturadosShow(): Observable<Capturados[]> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });
      //peticion con headers para cargar los xuxemons capturados
      return this.http.get<Capturados[]>('http://127.0.0.1:8000/api/capturados', { headers });
    }

    EquipoShow(): Observable<any> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });
      //peticion con headers para cargar tu equipo
      return this.http.get<any>('http://127.0.0.1:8000/api/equipo', { headers });
    }

    alimentar(request:any): Observable<any> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });
        let params = new HttpParams()
        .set('capturados_id', Number(request.capturado_id))
        .set('cantidad', Number(request.cantidad))
        .set('candy_id', Number(request.candy_id));
      //peticion con headers para cargar los xuxemons capturados
      return this.http.post('http://127.0.0.1:8000/api/capturados/dar',{}, { params, headers });
    }

    equipar(capturado:any): Observable<any> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });


      //peticion con headers para cargar los xuxemons capturados
      return this.http.post('http://127.0.0.1:8000/api/equipo', { capturado }, { headers });
    }

    desequipar(capturado:any): Observable<any> {
      // token de sesion
      const authToken = this.tokenService.getToken();
      // header con el token
        const headers = new HttpHeaders({
          Authorization: `Bearer ${authToken}`,
        });
        let params = new HttpParams()
        .set('capturado', capturado.toString());

      //peticion con headers para cargar los xuxemons capturados
      return this.http.delete('http://127.0.0.1:8000/api/equipo', { params,  headers });
    }

}
