import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { Capturados } from 'src/models/capturados.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class XuxemonService {
  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient, public tokenService: TokenService) {
  }

  XuxeUpdate(xuxe: any, id: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de actualizacion

    return this.http.put(`${this.apiUrl}xuxemons/${id}`, xuxe, { headers });
  }

  XuxeCreate(xuxemon: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de crear
    return this.http.post(`${this.apiUrl}xuxemons/`, xuxemon, { headers });
  }

  XuxeDelete(id: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de delete
    return this.http.delete(`${this.apiUrl}xuxemons/${id}`, { headers });
  }

  XuxeIndex(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}capturados`, { headers });
  }

  //funciones de xuxemon/inventario

  XuxemonShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get(`${this.apiUrl}xuxemons`, { headers });
  }

  CapturadosShow(): Observable<Capturados[]> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get<Capturados[]>(`${this.apiUrl}capturados`, { headers });
  }

  EquipoShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para cargar tu equipo
    return this.http.get<any>(`${this.apiUrl}equipo`, { headers });
  }

  alimentar(request: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    let params = new HttpParams()
      .set('capturados_id', Number(request.capturado_id))
      .set('cantidad', Number(request.cantidad))
      .set('candy_id', Number(request.candy_id));
    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}capturados/dar`, {}, { params, headers });
  }

  equipar(capturado: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });


    //peticion con headers para cargar los xuxemons capturados
    return this.http.post(`${this.apiUrl}equipo`, { capturado }, { headers });
  }

  desequipar(capturado: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    let params = new HttpParams()
      .set('capturado', capturado.toString());

    //peticion con headers para cargar los xuxemons capturados
    return this.http.delete(`${this.apiUrl}equipo`, { params, headers });
  }

}
