import { Injectable } from '@angular/core';
import { Observable } from "rxjs";
import { TokenService } from '../services/token.service';
import { HttpClient, HttpHeaders } from "@angular/common/http";



@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http: HttpClient, public tokenService: TokenService) {
  }

  Login(user: any): Observable<any> {
    return this.http.post("http://127.0.0.1:8000/api/login", user);
  }
  Registrar(user: any): Observable<any> {
    return this.http.post("http://127.0.0.1:8000/api/register", user);
  }

  XuxeUpdate(xuxe: any, id:any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers de actualizacion

    return this.http.put(`http://127.0.0.1:8000/api/xuxemons/${id}`, xuxe, { headers });
  }

  XuxeCreate(xuxemon: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de crear
    return this.http.post(`http://127.0.0.1:8000/api/xuxemons/`, xuxemon, { headers });
  }

  XuxeDelete(id: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();

    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers de delete
    return this.http.delete(`http://127.0.0.1:8000/api/xuxemons/${id}`, { headers });
  }

  //funciones de xuxemon/inventario

  InventarioShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
      const headers = new HttpHeaders({
        Authorization: `Bearer ${authToken}`,
      });
    //peticion con headers para cargar los xuxemons capturados
    return this.http.get('http://127.0.0.1:8000/api/capturados', { headers });
  }
}
