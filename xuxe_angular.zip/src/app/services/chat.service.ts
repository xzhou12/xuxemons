import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { TokenService } from './token.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient, public tokenService: TokenService) { }


  enviarMensaje(user: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });

    let params = new HttpParams().set('user_id', user);

    //Peticion con headers para buscar un amigo
    return this.http.post(`${this.apiUrl}api/chat`, null, { headers, params });
  }



  /*-------------------S'ha de arreglar------------------------*/
  mirarMensaje(user: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });

    let params = new HttpParams().set('user_id', user);

    //Peticion con headers para buscar un amigo
    return this.http.get(`${this.apiUrl}api/chat`);
  }

  
}
