import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TokenService } from './token.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AmigosService {
  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient, public tokenService: TokenService) { }

  buscarAmigos(request: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });

    // Create an instance of HttpParams and set the parameter
    let params = new HttpParams().set('name', request);

    //Peticion con headers para buscar un amigo
    return this.http.post(`${this.apiUrl}friends/search`, null, { headers, params });
  }

  enviarSolicitud(user: any): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    let params = new HttpParams().set('user_id', user);
    //Peticion con headers para enviar solicitud
    console.log(params.get('user_id'))
    return this.http.post(`${this.apiUrl}friends/add`, null, { params, headers });
  }

  solicitudesShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //Peticion con headers para ver la solicitudes del usuario
    return this.http.get(`${this.apiUrl}friends/request`, { headers });
  }

  aceptarSolicitud(user_id: number): Observable<any> {
    // Get the session token
    const authToken = this.tokenService.getToken();

    // Create headers with the token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });

    // Make the request with headers to accept a friend request
    return this.http.post(`${this.apiUrl}friends/accept`, { user_id }, { headers });
  }

  rechazarSolicitud(user_id: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para rechazar una solictud
    return this.http.post(`${this.apiUrl}friends/decline`, { user_id }, { headers });
  }

  amigosShow(): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    //peticion con headers para ver la solicitudes del usuario
    return this.http.get(`${this.apiUrl}friends/show`, { headers });
  }

  eliminarAmigos(user_id: number): Observable<any> {
    // token de sesion
    const authToken = this.tokenService.getToken();
    // header con el token
    const headers = new HttpHeaders({
      Authorization: `Bearer ${authToken}`,
    });
    const params = new HttpParams().set('user_id', user_id);
    //peticion con headers para eliminar el amigo
    return this.http.delete(`${this.apiUrl}friends/delete`, { params, headers });
  }
}
