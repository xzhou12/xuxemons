import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { Xuxemon } from 'src/models/xuxemon.model';
import { XuxemonService } from '../services/xuxemon.service';
import { TokenService } from '../services/token.service';
import { Capturados } from 'src/models/capturados.model';
import { MochilaService } from '../services/mochila.service';
import { Mochila } from 'src/models/Mochila.model';
import { ConfigService } from '../services/config.service';
import { Infectado } from 'src/models/infectados.model';
import { Enfermedad } from 'src/models/enfermedad.model';

@Component({
  selector: 'app-inventario',
  templateUrl: './inventario.component.html',
  styleUrls: ['./inventario.component.css']
})
export class InventarioComponent implements OnInit {
  xuxes: Mochila[];
  xuxemons: Xuxemon[];
  showAlimentarMenu = false;
  userRole: String | null = this.tokenService.getRole();
  capturados: Capturados[] = [];
  cantidadXuxes: any;
  capturado: any;
  equipados: Capturados[];
  Enfermedad: Enfermedad[] = [];
  enfermo: Enfermedad;
  infectados: Infectado[];

  constructor(public xuxemonService: XuxemonService, private router: Router, public tokenService: TokenService, public mochilaService: MochilaService, public configService: ConfigService) { }

  ngOnInit(): void {
    this.CargarRol();
    this.cargarEquipo();
    //this.getPorcentajeDiabetes();

  }

  getPorcentajeDiabetes(caramelos_dados: number) {
    return Math.min((caramelos_dados / 10) * 100, 100);
  }

  getClasesTipo(xuxeTipo: string): any {
    return {
      tipoTierra: xuxeTipo === 'Tierra',
      tipoAgua: xuxeTipo === 'Agua',
      tipoAire: xuxeTipo === 'Aire'
    };
  }

  getClasesTamano(Tamano: string): any {
    return {
      xuxe_small: Tamano === 'small',
      xuxe_medium: Tamano === 'medium',
      xuxe_large: Tamano === 'large'
    };
  }

  getClasescolor(xuxeTipo: string): any {
    return {
      colorTierra: xuxeTipo === 'Tierra',
      colorAgua: xuxeTipo === 'Agua',
      colorAire: xuxeTipo === 'Aire'
    };
  }

  //editar el xuxemon en concreto
  editar(xuxe: any) {

    const navigationExtras: NavigationExtras = {
      queryParams: {
        id: xuxe.id,
        name: xuxe.name,
        tipo: xuxe.tipo,
        archivo: xuxe.archivo,
      }
    };

    this.router.navigate(['/xuxemons/editar'], navigationExtras);
  }


  //elimina el xuxemon en concreto
  eliminar($id: any) {
    //se subscribe para recibir info de la funcion
    this.xuxemonService.XuxeDelete($id).subscribe(
      //si sale bien
      (data: any) => {
        console.log(data);
        //redirije para recargar y avisa de que el xuxemon se ha eliminado
        this.router.navigate(['/xuxemons']);
        alert('Xuxemon eliminado correctamente.');
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo eliminar el Xuxemon');
        throw new Error(error);
      });
  }

  CargarRol() {
    this.tokenService.getRole()
      .subscribe((Data: String | null) => {
        this.userRole = Data; // Assign the received data to the array
      });
  }


  toggleAlimentar(id: any) {
    this.capturado = id;
    this.showAlimentarMenu = !this.showAlimentarMenu;
    this.configService.getPorcentajeEnfermedad().subscribe((data: Enfermedad[]) => {
      this.Enfermedad[0] = data[0];
      this.Enfermedad[1] = data[1];
      this.Enfermedad[2] = data[2];
      // Filter the curas array based on Enfermedad.cura
      if (this.Enfermedad.some(enfermedad => enfermedad.cura)) {
        this.mochilaService.MochilaCandyShow().subscribe(Data => {
          this.xuxes = Data; // Assign the received data to the array

          this.xuxes = this.xuxes.filter(cura =>
            !this.Enfermedad.some(enfermedad => cura.objetos_id === enfermedad.cura)
          );
        });
      }
    });
  }



  alimentar(id: number, cantidad: number) {
    const request = {
      candy_id: id,
      cantidad: cantidad,
      capturado_id: this.capturado,

    };

    this.xuxemonService.alimentar(request).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarEquipo();
        this.toggleAlimentar(0);
      },

      //Si sale mal
      (error) => {
        console.log(error);
        throw new Error(error);
      });
  }

  debug() {
    alert('Botón Debug funciona! :3 (en verdad no)');
  }


  agregarAlEquipo(capturado: any) {
    this.xuxemonService.equipar(capturado.id).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarEquipo();
      },
      //Si sale mal
      (error) => {
        alert("El equipo esta lleno.")
        throw new Error(error);
      });

  }

  quitarEquipo(capturado: any) {
    this.xuxemonService.desequipar(capturado.id).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarEquipo();
      },
      //Si sale mal
      (error) => {
        console.log(error);
        throw new Error(error);
      });

  }
  cargarEquipo() {
    // Fetch Capturados data
    this.xuxemonService.CapturadosShow().subscribe(capturadosData => {
      // Fetch Infectados data
      this.configService.getInfectados().subscribe(infectadosData => {
        // Map infectadosData to an object for easier lookup
        const infectadosMap: { [capturados_id: number]: Infectado[] } = {};
        infectadosData.forEach(infectado => {
          if (!infectadosMap[infectado.capturados_id]) {
            infectadosMap[infectado.capturados_id] = [];
          }
          infectadosMap[infectado.capturados_id].push(infectado);
        });

        // Separate capturados into two arrays based on equipado property
        this.equipados = capturadosData.filter(capturado => capturado.equipado === 1);
        this.capturados = capturadosData.filter(capturado => capturado.equipado !== 1);

        // Assign enfermedades based on matching infectados
        this.equipados.forEach(equipoItem => {
          // Find all infectados affecting this equipoItem
          const matchingInfectados = infectadosMap[equipoItem.id] || [];
          // Initialize enfermedad properties
          equipoItem.enfermedad1 = this.enfermo;
          equipoItem.enfermedad2 = this.enfermo;
          equipoItem.enfermedad3 = this.enfermo;
          // Assign enfermedades based on matching infectados
          matchingInfectados.forEach(matchingInfectado => {
            if (matchingInfectado.enfermedad.id === 1) {
              equipoItem.enfermedad1 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 2) {
              equipoItem.enfermedad2 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 3) {
              equipoItem.enfermedad3 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            }
          });
        });
        // Assign enfermedades based on matching infectados
        this.capturados.forEach(equipoItem => {
          // Find all infectados affecting this equipoItem
          const matchingInfectados = infectadosMap[equipoItem.id] || [];
          // Initialize enfermedad properties
          equipoItem.enfermedad1 = this.enfermo;
          equipoItem.enfermedad2 = this.enfermo;
          equipoItem.enfermedad3 = this.enfermo;
          // Assign enfermedades based on matching infectados
          matchingInfectados.forEach(matchingInfectado => {
            if (matchingInfectado.enfermedad.id === 1) {
              equipoItem.enfermedad1 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 2) {
              equipoItem.enfermedad2 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 3) {
              equipoItem.enfermedad3 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            }
          });
        });
      });
    });
  }
}
