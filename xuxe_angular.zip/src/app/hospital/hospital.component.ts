import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MochilaService } from '../services/mochila.service';
import { TokenService } from '../services/token.service';
import { XuxemonService } from '../services/xuxemon.service';
import { Mochila } from 'src/models/Mochila.model';
import { Capturados } from 'src/models/capturados.model';
import { ConfigService } from '../services/config.service';
import { Infectado } from 'src/models/infectados.model';
import { Enfermedad } from 'src/models/enfermedad.model';

@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css']
})
export class HospitalComponent implements OnInit {
  curas: Mochila[];
  showCuras = false;
  userRole: String | null = this.tokenService.getRole();
  equipo: Capturados[];
  capturado: any;
  infectados: Infectado[];
  Enfermedad: Enfermedad[] = [];
  CantidadXuxes: any;


  constructor(public xuxemonService: XuxemonService, private router: Router, public tokenService: TokenService, public mochilaService: MochilaService, public configService: ConfigService) { }

  ngOnInit(): void {
    this.CargarRol();
    this.CargarEquipo();
  }

  getPorcentajeDiabetes(caramelos_dados: number) {
    return Math.min((caramelos_dados / 10) * 100, 100);
  }

  getClasesTipo(xuxeTipo: string): any {
    return {
      tipoTierra: xuxeTipo === 'Tierra',
      tipoAgua: xuxeTipo === 'Agua',
      tipoAire: xuxeTipo === 'Aire'
    };
  }

  getClasesTamano(Tamano: string): any {
    return {
      xuxe_small: Tamano === 'small',
      xuxe_medium: Tamano === 'medium',
      xuxe_large: Tamano === 'large'
    };
  }

  getClasescolor(xuxeTipo: string): any {
    return {
      colorTierra: xuxeTipo === 'Tierra',
      colorAgua: xuxeTipo === 'Agua',
      colorAire: xuxeTipo === 'Aire'
    };
  }

  CargarRol() {
    this.tokenService.getRole()
      .subscribe((Data: String | null) => {
        this.userRole = Data; // Assign the received data to the array
      });
  }

  CargarEquipo() {

    this.configService.getInfectados().subscribe(infectadosData => {
      this.infectados = infectadosData; // Assign the received data to the array
  
      this.xuxemonService.CapturadosShow().subscribe(equipoData => {
        this.equipo = equipoData; // Assign the received data to the array
  
        // Once both arrays are loaded, filter out elements that appear in both
        if (this.equipo && this.infectados) {
          this.equipo = this.equipo.filter(equipoItem =>
            this.infectados.some(infectadoItem => infectadoItem.capturados_id === equipoItem.id)
          );
        }
      });
    });

  }

  toggleCurar(id: any) {
    this.configService.getPorcentajeEnfermedad().subscribe((data: Enfermedad[]) => {
      this.Enfermedad[0] = data[0];
      this.Enfermedad[1] = data[1];
      this.Enfermedad[2] = data[2];
      // Filter the curas array based on Enfermedad.cura
      if (this.Enfermedad.some(enfermedad => enfermedad.cura)) {
        this.mochilaService.MochilaCandyShow().subscribe(Data => {
          this.curas = Data; // Assign the received data to the array

          this.curas = this.curas.filter(cura =>
            this.Enfermedad.some(enfermedad =>  cura.objetos_id === enfermedad.cura)
          );
        });
      }
    });

    this.capturado = id;
    this.showCuras = !this.showCuras;
  }

  alimentar(id: number, cantidad: number) {
    const request = {
      candy_id: id,
      cantidad: cantidad,
      capturado_id: this.capturado,
      
    };

    this.xuxemonService.alimentar(request).subscribe(
      //si sale bien
      (data: any) => {
        this.CargarEquipo();
        this.toggleCurar(0);
        console.log(1)
      },

      //Si sale mal
      (error) => {
        console.log(error);
        throw new Error(error);
      });
  }

}
