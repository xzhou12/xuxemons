import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';
import { AmigosService } from '../services/amigos.service';
import { Amigo } from 'src/models/amigo.model';
import { User } from 'src/models/user.model';
import { AmigoPeticion } from 'src/models/amigoPeticion.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.css']
})
export class SocialComponent implements OnInit {
  usuarios: User[];
  amigos: Amigo[];
  peticiones: AmigoPeticion[];
  buscador: string;
  amigoChateando: Amigo;
  modoChat: boolean = false;
  chat: any[];
  mensaje: string = '';
  intervalId: any;
  constructor(public tokenService: TokenService, public amigoService: AmigosService, private router: Router) { }

  ngOnInit(): void {

    this.CargarAmigos()
    this.CargarPeticiones()
  }

  checkModoChat() {

    /*
    while(this.modoChat){
      this.intervalId = setInterval(() => {
      if (this.modoChat) {
        this.cargarChat();
      } else {
        clearInterval(this.intervalId);
      }
    }, 5000);
    }
    */
  }

  CargarUsuarios() {
    this.amigoService.buscarAmigos(this.buscador)
      .subscribe((Data: User[]) => {
        this.usuarios = Data; // Assign the received data to the array
      });
  }
  CargarAmigos() {
    this.amigoService.amigosShow()
      .subscribe((Data: Amigo[]) => {
        this.amigos = Data; // Assign the received data to the array
      });
  }

  CargarPeticiones() {
    this.amigoService.solicitudesShow()
      .subscribe((Data: AmigoPeticion[]) => {
        this.peticiones = Data; // Assign the received data to the array
      });
      this.checkModoChat()
  }


  enviarPeticion(user: any) {
    this.amigoService.enviarSolicitud(user).subscribe(
      //si sale bien
      (data: any) => {
        alert("Solicitud enviada correctamente.")
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  aceptarPeticion(id: number) {
    this.amigoService.aceptarSolicitud(id).subscribe(
      //si sale bien
      (data: any) => {
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  denegarPeticion(id: any) {
    this.amigoService.rechazarSolicitud(id).subscribe(
      //si sale bien
      (data: any) => {
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  eliminarAmigo(id: any) {
    if (confirm("Seguro que quieres dejar de ser amigos?")) {
      this.amigoService.eliminarAmigos(id).subscribe(
        //si sale bien
        (data: any) => {
          this.recargarTodo();
        },
        //si sale mal
        (error) => {
          throw new Error(error);
        });
    }
  }

  recargarTodo() {
    setTimeout(() => {
      window.location.reload();
    }, 100);
  }

  abrirChat(amigo: Amigo) {
    this.amigoChateando = amigo;
    this.modoChat = true;
    this.cargarChat()
    this.checkModoChat()
  }
  
  cerrarChat() {
    this.modoChat = false;
  }

  cargarChat() {
        this.amigoService.mirarMensaje(this.amigoChateando.id).subscribe(
          (data) => {
            this.chat = data;
          },
          (error) => { throw new Error(error); }
        )

  }
  enviarMensaje() {
    console.log(this.amigoChateando.id)
    this.amigoService.enviarMensaje(this.amigoChateando.id, this.mensaje).subscribe(
      (data) => {
        this.cargarChat()
        console.log(data)
      },
      (error) => { throw new Error(error); }
    )
  }
}
