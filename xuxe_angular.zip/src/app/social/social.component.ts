import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';
import { AmigosService } from '../services/amigos.service';
import { Amigo } from 'src/models/amigo.model';
import { User } from 'src/models/user.model';
import { AmigoPeticion } from 'src/models/amigoPeticion.model';

@Component({
  selector: 'app-social',
  templateUrl: './social.component.html',
  styleUrls: ['./social.component.css']
})
export class SocialComponent implements OnInit {
  usuarios: User[];
  amigos: Amigo[];
  peticiones: AmigoPeticion[];
  buscador: string;
  constructor(public tokenService: TokenService, public amigoService: AmigosService) { }

  ngOnInit(): void {

    this.CargarAmigos()
    this.CargarPeticiones()
  }


  CargarUsuarios() {
    this.amigoService.buscarAmigos(this.buscador)
      .subscribe((Data: User[]) => {
        this.usuarios = Data; // Assign the received data to the array
      });
  }
  CargarAmigos() {
    this.amigoService.amigosShow()
      .subscribe((Data: Amigo[]) => {
        this.amigos = Data; // Assign the received data to the array
      });
  }

  CargarPeticiones() {
    this.amigoService.solicitudesShow()
      .subscribe((Data: AmigoPeticion[]) => {
        this.peticiones = Data; // Assign the received data to the array
      });
  }


  enviarPeticion(user:any) {
    this.amigoService.enviarSolicitud(user).subscribe(
      //si sale bien
      (data: any) => {
        alert("Solicitud enviada correctamente.")
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  aceptarPeticion(id: number) {
    this.amigoService.aceptarSolicitud(id).subscribe(
      //si sale bien
      (data: any) => {
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  denegarPeticion(id: any) {
    this.amigoService.rechazarSolicitud(id).subscribe(
      //si sale bien
      (data: any) => {
        this.recargarTodo();
      },
      //si sale mal
      (error) => {
        throw new Error(error);
      });
  }

  eliminarAmigo(id: any) {
    if (confirm("Seguro que quieres dejar de ser amigos?")) {
      this.amigoService.eliminarAmigos(id).subscribe(
        //si sale bien
        (data: any) => {
          this.recargarTodo();
        },
        //si sale mal
        (error) => {
          throw new Error(error);
        });
    }
  }

  recargarTodo(){
    setTimeout(() => {
      window.location.reload();
    }, 100);
  }
}
