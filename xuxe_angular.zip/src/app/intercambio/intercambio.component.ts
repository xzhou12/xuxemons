import { ResourceLoader } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { timeout } from 'rxjs';
import { Amigo } from 'src/models/amigo.model';
import { Capturados } from 'src/models/capturados.model';
import { Infectado } from 'src/models/infectados.model';
import { Solicitud } from 'src/models/Solicitud.model';
import { User } from 'src/models/user.model';
import { Xuxemon } from 'src/models/xuxemon.model';
import { AmigosService } from '../services/amigos.service';
import { ConfigService } from '../services/config.service';
import { IntercambioService } from '../services/intercambio.service';
import { MochilaService } from '../services/mochila.service';
import { TokenService } from '../services/token.service';
import { XuxemonService } from '../services/xuxemon.service';

@Component({
  selector: 'app-intercambio',
  templateUrl: './intercambio.component.html',
  styleUrls: ['./intercambio.component.css']
})
export class IntercambioComponent implements OnInit {

  xuxemons: Xuxemon[];
  amigos: Amigo[];
  amigo: any;
  user: any;
  userRole: String | null = this.tokenService.getRole();
  capturados: Capturados[] = [];
  capturado: Capturados;
  modoIntercambio: boolean = false;
  modoRespuesta: boolean = false;
  solicitudes: Solicitud[] = [];

  constructor(public xuxemonService: XuxemonService, public tokenService: TokenService, public mochilaService: MochilaService,
    public configService: ConfigService, public amigoService: AmigosService, public swapServicio: IntercambioService) { }

  ngOnInit(): void {
    this.cargarSolicitudes();
    this.CargarAmigos()
  }

  getPorcentajeDiabetes(caramelos_dados: number) {
    return Math.min((caramelos_dados / 10) * 100, 100);
  }

  getClasesTipo(xuxeTipo: string): any {
    return {
      tipoTierra: xuxeTipo === 'Tierra',
      tipoAgua: xuxeTipo === 'Agua',
      tipoAire: xuxeTipo === 'Aire'
    };
  }

  getClasesTamano(Tamano: string): any {
    return {
      xuxe_small: Tamano === 'small',
      xuxe_medium: Tamano === 'medium',
      xuxe_large: Tamano === 'large'
    };
  }

  getClasescolor(xuxeTipo: string): any {
    return {
      colorTierra: xuxeTipo === 'Tierra',
      colorAgua: xuxeTipo === 'Agua',
      colorAire: xuxeTipo === 'Aire'
    };
  }

  CargarAmigos() {
    this.amigoService.amigosShow()
      .subscribe((Data: Amigo[]) => {
        this.amigos = Data; // Assign the received data to the array
      });
  }

  cargarSolicitudes() {
    this.swapServicio.mostrarSolicitud()
      .subscribe((data:Solicitud[]) => {
        this.solicitudes = data;
      },(error)=>{
        console.log(error.error.message)
      });
  }

  cargarEquipo() {
    // Fetch Capturados data
    this.xuxemonService.CapturadosShow().subscribe(capturadosData => {
      // Fetch Infectados data
      this.configService.getInfectados().subscribe(infectadosData => {
        // Map infectadosData to an object for easier lookup
        const infectadosMap: { [capturados_id: number]: Infectado[] } = {};
        infectadosData.forEach(infectado => {
          if (!infectadosMap[infectado.capturados_id]) {
            infectadosMap[infectado.capturados_id] = [];
          }
          infectadosMap[infectado.capturados_id].push(infectado);
        });

        // Separate capturados into two arrays based on equipado property
        this.capturados = capturadosData.filter(capturado => capturado.equipado !== 1);

        // Assign enfermedades based on matching infectados
        this.capturados.forEach(equipoItem => {
          // Find all infectados affecting this equipoItem
          const matchingInfectados = infectadosMap[equipoItem.id] || [];
          // Assign enfermedades based on matching infectados
          matchingInfectados.forEach(matchingInfectado => {
            if (matchingInfectado.enfermedad.id === 1) {
              equipoItem.enfermedad1 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 2) {
              equipoItem.enfermedad2 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            } else if (matchingInfectado.enfermedad.id === 3) {
              equipoItem.enfermedad3 = matchingInfectado.enfermedad;
              equipoItem.infected = true;
            }
          });
        });
      });
    });
  }

  ToggleIntercambio(amigo?: any) {
    if(amigo){
    this.amigo = amigo;
    }
    this.cargarEquipo();
    this.modoIntercambio = !this.modoIntercambio
  }
  ToggleRespuesta(user?: any) {
    if(user){
    this.user = user;
    }
    this.cargarEquipo();
    this.modoRespuesta = !this.modoRespuesta
    this.modoIntercambio = !this.modoIntercambio
  }
  enviarIntercambio(capturado: Capturados) {
    this.swapServicio.enviarSolicitud(capturado.id, this.amigo)
      .subscribe(() => {
        alert("peticion enviada correctamente")
        this.modoIntercambio = !this.modoIntercambio
        setTimeout(function() {
          location.reload();
      }, 10);
      },(error)=>{
        console.log(error)
        alert("Hubo un error al enviar la peticion de  intercambio")
      });
  }
  RespuestaIntercambio(capturado: Capturados) {
    console.log(capturado.id)
    this.swapServicio.responderSolicitud(capturado.id, this.user)
      .subscribe(() => {
        alert("Respuesta enviada correctamente")
        this.modoIntercambio = !this.modoIntercambio
        this.modoRespuesta = !this.modoRespuesta
        setTimeout(function() {
          location.reload();
      }, 10);
      },(error)=>{
        console.log(error)
        alert("Hubo un error al enviar la peticion de  intercambio")
      });
  }
  aceptarIntercambio(amigo: any) {
    this.swapServicio.aceptarSolicitud(amigo)
      .subscribe((data) => {
        alert("Intercambio realizado.")
        setTimeout(function() {
          location.reload();
      }, 10);
      },(error)=>{
        console.log(error)
        alert(error.error.message)
      });
  }
  denegarIntercambio(amigo: any) {
    this.swapServicio.denegarSolicitud(amigo)
      .subscribe(() => {
        alert("Intercambio cancelado.")
        setTimeout(function() {
          location.reload();
      }, 10);
      },(error)=>{
        console.log(error)
        alert(error.error.message)
      });
  }
}
