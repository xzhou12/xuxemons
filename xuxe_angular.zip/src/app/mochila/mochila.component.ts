import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';
import { Mochila } from 'src/models/Mochila.model';
import { MochilaService } from '../services/mochila.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mochila',
  templateUrl: './mochila.component.html',
  styleUrls: ['./mochila.component.css']
})
export class MochilaComponent implements OnInit {
  userRole: String | null;
  mochila: Mochila[];
  constructor(public tokenService: TokenService, public mochilaService: MochilaService, private router: Router) { }

  ngOnInit(): void {
    this.CargarRol()
    this.CargarObjetos()
  }

  CargarRol() {
    this.tokenService.getRole()
      .subscribe((Data: String | null) => {
        this.userRole = Data; // Assign the received data to the array
      });
  }

  CargarObjetos() {
    this.mochilaService.MochilaShow()
      .subscribe(Data => {
        this.mochila = Data; // Assign the received data to the array
      });
  }

  debugCofre() {
    this.mochilaService.DebugCofre().subscribe(
      //si sale bien
      (data: any) => {
        this.CargarObjetos()
      },
      //si sale mal
      (error) => {
        console.log(error);
        throw new Error(error);
      });
  }

  abrirCofre() {
    this.mochilaService.AbrirCofre().subscribe(
      //si sale bien
      (data: any) => {
        alert(data.message)
        this.CargarObjetos()
      },
      //si sale mal
      (error) => {
        alert("Ya has canjeado por el dia de hoy!")
        console.log(error);
        throw new Error(error);
      });
  }
}
