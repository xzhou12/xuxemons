import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsersService } from '../services/users.service';
import { TokenService } from '../services/token.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  LoginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  });
  constructor(public userService: UsersService, private router: Router, public tokenService: TokenService) { 
  }

  ngOnInit(): void {
  }

  Login() {
    this.userService.Login(this.LoginForm.value).subscribe(
      (data: any) => {
        this.router.navigate(['/xuxemons']);
        const token = data.access_token;
        this.tokenService.setToken(data);
        alert('Sesion iniciada correctamente.');
      },
      (error) => {
        alert('Correo o contraseña incorectos');
        throw new Error(error);
      });
  }
}
