import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { TokenService } from '../services/token.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  LoginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  });
  constructor(public authService: AuthService, private router: Router, public tokenService: TokenService) { 
  }

  ngOnInit(): void {
  }

  Login() {
    this.authService.Login(this.LoginForm.value).subscribe(
      (data: any) => {
        this.router.navigate(['/home']);
        this.tokenService.setToken(data);
        alert('Sesion iniciada correctamente.');
      },
      (error) => {
        alert('Correo o contraseña incorectos');
        throw new Error(error);
      });
  }
}
