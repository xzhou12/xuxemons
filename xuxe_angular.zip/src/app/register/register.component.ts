import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../services/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  RegisterForm: FormGroup = new FormGroup({
    name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    password_confirmation: new FormControl('', [Validators.required]),
    rol: new FormControl('user')
  });
  constructor(public userService: UsersService, private router: Router) { }

  ngOnInit(): void {
  }

  Registrar() {
    //comprueba las contraseñas sean las mismas
    if (this.RegisterForm.value.contraseña === this.RegisterForm.value.RepetirContraseña) {
      this.userService.Registrar(this.RegisterForm.value).subscribe(
        (data) => {
          console.log(data);
          this.router.navigate(['/login']);
          alert('Usuario registrado correctamente.');
        },
        (error) => {
          alert('No se pudo registrar el usuario correctamente');
          throw new Error(error);
        }
      );
    } else {
      alert("Las contraseñas no coinciden");
    }
  }
}
