import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denied',
  templateUrl: './denied.component.html',
  styleUrls: ['./denied.component.css']
})
export class DeniedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
