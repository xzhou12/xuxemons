import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ErrorComponent } from './error/error.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { XuxemonsComponent } from './xuxemons/xuxemons.component';
import { HttpClientModule } from '@angular/common/http';
import { DeniedComponent } from './denied/denied.component';
import { HomeComponent } from './home/home.component';
import { InventarioComponent } from './inventario/inventario.component';
import { HospitalComponent } from './hospital/hospital.component';
import { MochilaComponent } from './mochila/mochila.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { CrearComponent } from './xuxemons/crear/crear.component';
import { EditComponent } from './xuxemons/edit/edit.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ErrorComponent,
    XuxemonsComponent,
    DeniedComponent,
    HomeComponent,
    InventarioComponent,
    HospitalComponent,
    MochilaComponent,
    FooterComponent,
    HeaderComponent,
    CrearComponent,
    EditComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
