import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { XuxemonService } from 'src/app/services/xuxemon.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  xuxemonForm!: FormGroup;
  xuxeData: any;
 

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.xuxeData = {
        id: params['id'],
        name: params['name'],
        tipo: params['tipo'],
        archivo: params['archivo']
      };
    });

    this.xuxemonForm.setValue({
      name: this.xuxeData.name || '',
      tipo: this.xuxeData.tipo || '',
      archivo: this.xuxeData.archivo || ''
    });
  }

  constructor(private fb: FormBuilder, public xuxemonService: XuxemonService, private router: Router, private route: ActivatedRoute) { 
    this.xuxemonForm = this.fb.group({
      name: ['', [Validators.required]],
      tipo: ['', [Validators.required]],
      archivo: ['', [Validators.required]],
    });
  }

  

  editarXuxemon() {
    console.log(this.xuxemonForm.value)
    //se subscribe para recibir info de la funcion
    this.xuxemonService.XuxeUpdate(this.xuxemonForm.value, this.xuxeData.id).subscribe(
      //si sale bien
      (data: any) => {
        console.log(data);
        //redirije para recargar y avisa de que el xuxemon se ha editado
        this.router.navigate(['/xuxemons']);
        alert('Xuxemon editado correctamente.');
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo editar el Xuxemon');
        throw new Error(error);
      });
  }
}
