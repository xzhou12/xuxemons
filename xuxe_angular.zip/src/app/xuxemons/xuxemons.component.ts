import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { Xuxemon } from 'src/models/xuxemon.model';
import { TokenService } from '../services/token.service';
import { XuxemonService } from '../services/xuxemon.service';
import { Capturados } from 'src/models/capturados.model';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-xuxemons',
  templateUrl: './xuxemons.component.html',
  styleUrls: ['./xuxemons.component.css']
})
export class XuxemonsComponent implements OnInit {
  xuxemons: Xuxemon[];
  capturados: Capturados[];
  userRole: String | null;
  constructor(public xuxemonService: XuxemonService, private router: Router, public tokenService: TokenService) { }

  ngOnInit(): void {
    this.CargarRol();
    this.CargarCapturados();
    this.cargarXuxemons();
  }
  CargarRol() {
    this.tokenService.getRole()
      .subscribe((Data: String | null) => {
        this.userRole = Data; // Assign the received data to the array
      });
  }

  getClasesTipo(xuxeTipo: string): any {
    return {
      tipoTierra: xuxeTipo === 'Tierra',
      tipoAgua: xuxeTipo === 'Agua',
      tipoAire: xuxeTipo === 'Aire'
    };
  }

  //carga xuxemons de la base de datos
  CargarCapturados() {
    this.xuxemonService.CapturadosShow()
      .subscribe(capturadosData => {
        this.capturados = capturadosData; // Assign the received data to the array
      });
  }

  cargarXuxemons() {
    this.xuxemonService.XuxemonShow().subscribe(
      //si sale bien
      (data: any) => {
        this.xuxemons = data.xuxemons;
      },
      //si sale mal
      (error) => {
        console.log(error);
        throw new Error(error);
      });
  }

  //comprueba si el xuxemon esta capurado
  comprobarCapturado(xuxe_id: any) {
    const isCaptured = this.capturados.some(capt => capt.xuxemon_id === xuxe_id);
    return isCaptured ? "visible" : "oculto";
  }

  crear() {
    this.router.navigate(['/xuxemons/crear']);
  }

  //editar el xuxemon en concreto
  editar(xuxe: any) {

    const navigationExtras: NavigationExtras = {
      queryParams: {
        id: xuxe.id,
        name: xuxe.name,
        tipo: xuxe.tipo,
        archivo: xuxe.archivo,
      }
    };

    this.router.navigate(['/xuxemons/editar'], navigationExtras);
  }

  //elimina el xuxemon en concreto
  eliminar($id: any) {

    const confirmacion = window.confirm('¿Seguro que desea eliminar este Xuxemon?');

    if (confirmacion) {
      //se subscribe para recibir info de la funcion
      this.xuxemonService.XuxeDelete($id).subscribe(
        //si sale bien
        (data: any) => {
          console.log(data);
          //redirije para recargar y avisa de que el xuxemon se ha eliminado
          this.router.navigate(['/xuxemons']);
          alert('Xuxemon eliminado correctamente.');
        },
        //si sale mal
        (error) => {
          console.log(error);
          //avisa de que algo ah ido mal
          alert('No se pudo eliminar el Xuxemon');
          throw new Error(error);
        });
    }
  }

  debug() {
    alert('Botón Debug funciona! :3 (en verdad no)');
  }

}
