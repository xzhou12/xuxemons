import { Component, Input, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { Xuxemon } from 'src/models/xuxemon.model';
import data from '../../assets/xuxemons.json';
import { UsersService } from '../services/users.service';
import { TokenService } from '../services/token.service';

@Component({
  selector: 'app-xuxemons',
  templateUrl: './xuxemons.component.html',
  styleUrls: ['./xuxemons.component.css']
})
export class XuxemonsComponent implements OnInit {
  @Input() xuxemons: Xuxemon[];
  xuxemonsView: boolean = false;
  userRole: String | null = this.tokenService.getRole();
  constructor(public userService: UsersService, private router: Router, public tokenService: TokenService) {


  }

  ngOnInit(): void {
    // Cargamos el fichero JSON
    const json: any = data.xuxemons;

    // Guardamos el fichero cargado en el array de xuxemons
    this.xuxemons = json;
  }

  crear() {
    this.router.navigate(['/xuxemons/crear']);
  }

  getClasesTipo(xuxeTipo: string): any {
    return {
      tipoTierra: xuxeTipo === 'Tierra',
      tipoAgua: xuxeTipo === 'Agua',
      tipoAire: xuxeTipo === 'Aire'
    };
  }

  //editar el xuxemon en concreto
  editar(xuxe: any) {

    const navigationExtras: NavigationExtras = {
      queryParams: {
        id: xuxe.id,
        name: xuxe.name,
        tipo: xuxe.tipo,
        archivo: xuxe.archivo,
      }
    };

    this.router.navigate(['/xuxemons/editar'], navigationExtras);
  }


  //elimina el xuxemon en concreto
  eliminar($id: any) {
    //se subscribe para recibir info de la funcion
    this.userService.XuxeDelete($id).subscribe(
      //si sale bien
      (data: any) => {
        console.log(data);
        //redirije para recargar y avisa de que el xuxemon se ha eliminado
        this.router.navigate(['/xuxemons']);
        alert('Xuxemon eliminado correctamente.');
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo eliminar el Xuxemon');
        throw new Error(error);
      });
  }

  debug() {
    alert('Botón Debug funciona! :3 (en verdad no)');
  }

}
