import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { XuxemonService } from 'src/app/services/xuxemon.service';
import { Xuxemon } from 'src/models/xuxemon.model';

@Component({
  selector: 'app-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.css']
})
export class CrearComponent implements OnInit {

  xuxemonForm!: FormGroup;
  xuxemon: Xuxemon | undefined;

  @Output() enviarFormulario: EventEmitter<Xuxemon> = new EventEmitter<Xuxemon>();
  @Output() ocultarForm = new EventEmitter<void>();

  constructor(private fb: FormBuilder, public xuxemonService: XuxemonService, private router: Router) {
    this.xuxemonForm = this.fb.group({
      name: new FormControl('', [Validators.required]),
      tipo: new FormControl('', [Validators.required]),
      archivo: new FormControl('', [Validators.required]),
    });

  }
  ngOnInit(): void {
  }

  //guarda el xuxemon en la base de datos
  guardarXuxemon(){
    //se subscribe para recibir info de la funcion
    this.xuxemonService.XuxeCreate(this.xuxemonForm.value).subscribe(
      //si sale bien
      (data: any) => {
        console.log(data);
        //redirije para recargar y avisa de que el xuxemon se ha creado
        this.router.navigate(['/xuxemons']);
        alert('Xuxemon creado correctamente.');
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo crear el Xuxemon');
        throw new Error(error);
      });
  }
}
