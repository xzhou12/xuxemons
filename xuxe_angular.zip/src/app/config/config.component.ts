import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigService } from '../services/config.service';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {
  tamanoDefault: string;
  tamano: string;
  mediumDefault: number;
  medium: number;
  bigDefault: number;
  big: number;


  constructor(public configService: ConfigService, private router: Router) {
  }

  ngOnInit(): void {
    this.cargarTamano();
    this.cargarMedium();
    this.cargarBig();
  }

  cargarTamano() {
    this.configService.getSize()
      .subscribe((data: string) => {
        this.tamanoDefault = data;
        this.tamano = data;
      });
  }

  cargarMedium() {
    this.configService.getMedium()
      .subscribe((data: number) => {
        this.mediumDefault = data;
        this.medium = data;
      });
  }

  cargarBig() {
    this.configService.getBig()
      .subscribe((data: number) => {
        this.bigDefault = data;
        this.big = data;
      });
  }

  guardarTamano() {
    const valor: string = this.tamano;
    this.configService.setSize(this.tamano).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarTamano();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }
  guardarMedium() {
    const valor: number = this.medium;
    this.configService.setMedium(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarMedium();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  guardarBig() {
    const valor: number = this.big;
    this.configService.setBig(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarBig();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

}
