import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ConfigService } from '../services/config.service';
import { Enfermedad } from 'src/models/enfermedad.model';
import { Capturados } from 'src/models/capturados.model';
import { XuxemonService } from '../services/xuxemon.service';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {
  tamanoDefault: string;
  tamano: string;
  mediumDefault: number;
  medium: number;
  bigDefault: number;
  big: number;
  xuxeDiariaDefault: number;
  xuxeDiaria: number;
  xuxesBajon: number;
  xuxesBajonDefault: number;
  Enfermedad: Enfermedad[] = [];
  EnfermedadDefault: Enfermedad[] = [];
  ListaXuxemons: Capturados[];
  selectedXuxemonId:number ;
  selectedenfermedadId:number ;
  constructor(public configService: ConfigService, public xuxemonService: XuxemonService, private router: Router) {
  }

  ngOnInit(): void {
    this.cargarTamano();
    this.cargarMedium();
    this.cargarBig();
    this.cargarXuxeDefault();
    this.cargarXuxesBajon();
    this.cargarEnfermedad();
  }

  cargarTamano() {
    this.configService.getSize()
      .subscribe((data: string) => {
        this.tamanoDefault = data;
        this.tamano = data;
      });
  }

  cargarMedium() {
    this.configService.getMedium()
      .subscribe((data: number) => {
        this.mediumDefault = data;
        this.medium = data;
      });
  }

  cargarBig() {
    this.configService.getBig()
      .subscribe((data: number) => {
        this.bigDefault = data;
        this.big = data;
      });
  }

  cargarXuxeDefault() {
    this.configService.getXuxeDefault()
      .subscribe((data: number) => {
        this.xuxeDiariaDefault = data;
        this.xuxeDiaria = data;
      });
  }

  cargarXuxesBajon() {
    this.configService.getXuxesBajon()
      .subscribe((data: number) => {
        this.xuxesBajonDefault = data;
        this.xuxesBajon = data;
      });
  }

  cargarEnfermedad() {
    this.configService.getPorcentajeEnfermedad()
      .subscribe((data: Enfermedad[]) => {
        this.EnfermedadDefault[0] = data[0];
        this.Enfermedad[0] = { ...data[0] };
        this.EnfermedadDefault[1] = data[1];
        this.Enfermedad[1] = { ...data[1] };
        this.EnfermedadDefault[2] = data[2];
        this.Enfermedad[2] = { ...data[2] };
      });
  }

  guardarTamano() {
    const valor: string = this.tamano;
    this.configService.setSize(this.tamano).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarTamano();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }
  guardarMedium() {
    const valor: number = this.medium;
    this.configService.setMedium(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarMedium();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  guardarBig() {
    const valor: number = this.big;
    this.configService.setBig(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarBig();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  guardarXuxesDiariasDefault() {
    const valor: number = this.xuxeDiaria;
    this.configService.setXuxeDefault(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarXuxeDefault();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  guardarXuxesBajon() {
    const valor: number = this.xuxesBajon;
    this.configService.setXuxesBajon(valor).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarXuxesBajon();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  guardarPorcentajeEnfermedad(id_enfermedad: number | undefined, porcentaje: number | undefined) {
    this.configService.setPorcentajeEnfermedad(id_enfermedad, porcentaje).subscribe(
      //si sale bien
      (data: any) => {
        this.cargarEnfermedad();
      },
      //si sale mal
      (error) => {
        console.log(error);
        //avisa de que algo ah ido mal
        alert('No se pudo cambiar la configuracion');
        throw new Error(error);
      });
  }

  //funciones para infectar y curar
  CargarXuxemons(){
    this.configService.CapturadosShow()
      .subscribe(
        (data: Capturados[]) => {
          this.ListaXuxemons = data;
        },
        //si sale mal
        (error) => {
          console.log(error);
          throw new Error(error);
        });
  }

  curarXuxemon(id_xuxemon:number){
    this.configService.CurarXuxemon(id_xuxemon)
      .subscribe(
        (data) => {
          alert("Xuxemon curado");
        },
        //si sale mal
        (error) => {
          console.log(error);
          alert("no se pudo curar al Xuxemon.")
          throw new Error(error);
      });
  }

  infectarXuxemon(id_xuxemon:number, id_enfermedad:number){
    this.configService.InfectarXuxemon(id_enfermedad, id_xuxemon)
      .subscribe(
        (data) => {
          alert("Xuxemon inectado");
        },
        //si sale mal
        (error) => {
          console.log(error);
          alert("no se pudo infectar al Xuxemon.")
          throw new Error(error);
      });
  }

}
