import { Component, OnInit } from '@angular/core';
import { TokenService } from '../services/token.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userRole: String | null;
  constructor(public tokenService: TokenService) { }

  ngOnInit(): void {
    this.CargarRol()
  }

  CargarRol() {
    this.tokenService.getRole()
    .subscribe((Data: String | null) => {
      this.userRole = Data; // Assign the received data to the array
    });
  }
}
