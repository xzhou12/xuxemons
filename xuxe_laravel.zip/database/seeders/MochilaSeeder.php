<?php

namespace Database\Seeders;

use App\Models\Mochila;
use App\Models\Objetos;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MochilaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        // Hace un select de los usuarios y los objetos
        $users = User::all('id');
        $objetos = Objetos::where('tipo', 'candy')->get('id');
        $monedas_id = Objetos::where('objeto', 'Monedas')->first()->id;

        // Loop por cada usuario registrado
        foreach ($users as $user) {

            // Loop 10 veces
            for ($i = 0; $i < 10; $i++) {

                // Selecciona un objeto aleatorio
                $rand_objeto = $objetos->random();

                // Comprueba si existe el registro
                $existe = Mochila::where('user_id', $user->id)
                    ->where('objetos_id', $rand_objeto->id)->exists();

                if ($existe) {
                    // Si exsite, coge el registro
                    $objeto = Mochila::where('user_id', $user->id)
                        ->where('objetos_id', $rand_objeto->id)->get()->first();

                    // E incrementa la cantidad
                    DB::transaction(function () use ($objeto) {
                        $objeto->increment('cantidad', rand(1, 10));
                    });

                } else {
                    // Si no, crea un registro con ese objeto
                    DB::transaction(function () use ($rand_objeto, $user) {
                        DB::table('mochilas')->insert([
                            'user_id' => $user->id,
                            'objetos_id' => $rand_objeto->id,
                            'cantidad' => rand(1, 10),
                        ]);
                    });
                }
            }

            // Comprueba si existe un registro de monedas
            $existe = Mochila::where('user_id', $user->id)
                ->where('objetos_id', $monedas_id)->exists();

            if ($existe) {
                // Si existe, incrementa la cantidad
                $monedas = Mochila::where('user_id', $user->id)
                    ->where('objetos_id', $monedas_id)->get()->first();

                DB::transaction(function () use ($monedas) {
                    $monedas->increment('cantidad', rand(300, 1000));
                });

            } else {
                // Si no, hace el insert desde 0
                DB::transaction(function () use ($monedas_id, $user) {
                    DB::table('mochilas')->insert([
                        'user_id' => $user->id,
                        'objetos_id' => $monedas_id,
                        'cantidad' => rand(300, 1000),
                    ]);
                });
            }


        }


    }
}
