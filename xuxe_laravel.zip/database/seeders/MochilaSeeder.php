<?php

namespace Database\Seeders;

use App\Models\Mochila;
use App\Models\Objetos;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MochilaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all('id');
        $objetos = Objetos::all('id');

        foreach ($users as $user) {

            /*
             * OTROS OBJETOS
             */
            for ($i = 0; $i < 10; $i++) {

                $rand_objeto = $objetos->random()->id;

                $mochila = Mochila::where('user_id', $user->id)
                    ->where('objetos_id', $rand_objeto)
                    ->first();

                if ($mochila) {
                    $mochila->increment('cantidad', rand(1, 10));
                } else {
                    DB::table('mochilas')->insert([
                        'user_id' => $user->id,
                        'objetos_id' => $objetos->random()->id,
                        'cantidad' => rand(1, 10),
                    ]);
                }
            }

            /*
             * MONEDAS
             */
            $monedas_id = Objetos::where('objeto', 'Monedas')->first()->id;

            $mochila = Mochila::where('user_id', $user->id)
                ->where('objetos_id', $monedas_id)
                ->first();

            if ($mochila) {
                $mochila->increment('cantidad', rand(1, 1000));
            } else {
                DB::table('mochilas')->insert([
                    'user_id' => $user->id,
                    'objetos_id' => $monedas_id,
                    'cantidad' => rand(1, 1000),
                ]);
            }

        }
    }
}
