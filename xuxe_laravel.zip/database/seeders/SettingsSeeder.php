<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $settings = [
            "default_size" => "small",
            "candy_medium" => "3",
            "candy_big" => "5",
        ];

        foreach ($settings as $parametro => $valor) {
            DB::table('settings')->insert([
                'parametro' => $parametro,
                'valor' => $valor,
            ]);
        }
    }
}
