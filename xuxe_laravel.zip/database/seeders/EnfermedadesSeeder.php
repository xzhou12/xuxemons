<?php

namespace Database\Seeders;

use App\Models\Enfermedades;
use App\Models\Objetos;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EnfermedadesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $xocolatina = Objetos::where('objeto', 'Xocolatina')->first();
        $inxulina = Objetos::where('objeto', 'Inxulina')->first();
        $xal_frutas = Objetos::where('objeto', 'Xal de frutas')->first();


        $enfermedades = [
            [
                'enfermedad' => 'Bajón de azúcar',
                'cod_enfermedad' => 'sugar_low',
                'descripcion' => 'Requiere +2 xuxes por nivel para crecer',
                'cura' => $xocolatina->id,
                'porcentaje' => 5,
            ],
            [
                'enfermedad' => 'Sobredosis de azúcar',
                'cod_enfermedad' => 'sugar_overdose',
                'descripcion' => 'Si el xuxemon está en activo no se puede usar para nada',
                'cura' => $inxulina->id,
                'porcentaje' => 10,
            ],
            [
                'enfermedad' => 'Atracón',
                'cod_enfermedad' => 'sugar_binge',
                'descripcion' => 'El xuxemon no puede alimentarse, por tanto el usuario no puede darle de comer',
                'cura' => $xal_frutas->id,
                'porcentaje' => 15,
            ],
        ];


        foreach ($enfermedades as $enfermedad) {
            DB::table('enfermedades')->insert($enfermedad);
        }

    }
}
