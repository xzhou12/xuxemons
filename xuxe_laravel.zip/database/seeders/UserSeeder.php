<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            [
                'name' => 'Admin',
                'email' => 'admin@admin.com',
                'password' => Hash::make('1234'),
                'id_code' => '6969',
                'rol' => 'admin',
            ],
            [
                'name' => 'User',
                'email' => 'user@user.com',
                'password' => Hash::make('1234'),
                'id_code' => '1010',
                'rol' => 'user',
            ],
            [
                'name' => 'Valenti',
                'email' => 'valenti@ilerna.com',
                'password' => Hash::make('1234'),
                'id_code' => '0606',
                'rol' => 'user',
            ],
            [
                'name' => 'Sandra',
                'email' => 'sandra@ilerna.com',
                'password' => Hash::make('1234'),
                'id_code' => '0707',
                'rol' => 'user',
            ],
            [
                'name' => 'Mauri',
                'email' => 'mauri@ilerna.com',
                'password' => Hash::make('1234'),
                'id_code' => '0808',
                'rol' => 'user',
            ],
            [
                'name' => 'Yassin',
                'email' => 'yassin@ilerna.com',
                'password' => Hash::make('1234'),
                'id_code' => '0909',
                'rol' => 'user',
            ],
        ];

        DB::table('users')->insert($users);
    }

}
