<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            'id' => 0,
            'name' => 'Admin',
            'email' => 'admin@admin.com',
            'password' => Hash::make('1234'),
            'id_code' => '6969',
            'rol' => 'admin',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'name' => 'User',
            'email' => 'user@user.com',
            'password' => Hash::make('1234'),
            'id_code' => '1010',
            'rol' => 'user',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'name' => 'Valenti',
            'email' => 'valenti@lleida.com',
            'password' => Hash::make('1234'),
            'id_code' => '0606',
            'rol' => 'user',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'name' => 'Sandra',
            'email' => 'sandra@lleida.com',
            'password' => Hash::make('1234'),
            'id_code' => '0707',
            'rol' => 'user',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'name' => 'Mauri',
            'email' => 'mauri@lleida.com',
            'password' => Hash::make('1234'),
            'id_code' => '0808',
            'rol' => 'user',
        ]);

        DB::table('users')->insert([
            'id' => 0,
            'name' => 'Yassin',
            'email' => 'yassin@lleida.com',
            'password' => Hash::make('1234'),
            'id_code' => '0909',
            'rol' => 'user',
        ]);
    }
}
