<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ObjetosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $objetos = [
            "Candy" => "candy.png",
            "Candy1" => "candy-1.png",
            "Candy2" => "candy-2.png",
            "Candies" => "candies.png",
            "Candies1" => "candies-1.png",
            "Candy Cane" => "candy-cane.png",
            "Chocolate bar" => "chocolate-bar.png",
            "Cotton Candy" => "cotton-candy.png",
            "Lollipop" => "lollipop.png",
            "Sweets" => "sweets.png",
        ];

        foreach ($objetos as $nombre => $archivo) {
            DB::table('objetos')->insert([
                'objeto' => $nombre,
                'archivo' => $archivo,
                'tipo' => 'candy',
            ]);
        }

        DB::table('objetos')->insert([
            'id' => 0,
            'objeto' => 'Monedas',
            'archivo' => 'coins.png',
            'tipo' => 'monedas',
        ]);
    }
}
