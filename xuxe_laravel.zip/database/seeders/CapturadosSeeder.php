<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Xuxemons;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CapturadosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all('id');
        $xuxemons = Xuxemons::all('id');

        foreach ($users as $user) {
            for ($i = 0; $i < 5; $i++) {
                DB::table('capturados')->insert([
                    'user_id' => $user->id,
                    'xuxemon_id' => $xuxemons->random()->id,
                ]);
            }
        }
    }
}
