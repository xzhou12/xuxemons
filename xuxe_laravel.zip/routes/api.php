<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\Controller;
use \App\Http\Controllers\XuxemonsController;
use App\Http\Controllers\CapturadosController;
use App\Http\Controllers\MochilaController;
use \App\Http\Controllers\SettingsController;
use \App\Http\Controllers\EquipoController;
use \App\Http\Controllers\EnfermedadesController;
use App\Http\Controllers\InfectadosController;
use \App\Http\Controllers\FriendsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// User login and register
Route::controller(Controller::class)->group(function () {

    // Registar
    Route::post('/register', 'register');

    // Loguearse
    Route::post('/login', 'login');

});

// Middleware para verificar que el usuario esta logueado
Route::middleware('auth:sanctum')->group(function () {

    // USUARIOS
    Route::controller(Controller::class)->group(function () {
        // Logout
        Route::post('/logout', 'logout');

        // Get role
        Route::get('/get-role', 'getRole');
    });

    // XUXEMONS
    Route::controller(XuxemonsController::class)->group(function () {

        // Mostrar todos los xuxemons
        Route::get('/xuxemons', 'show');

        // Mostrar un xuxemon
        Route::get('/xuxemons/{xuxemons}', 'showOne');

    });

    // CAPTURADOS
    Route::controller(CapturadosController::class)->group(function () {

        // Capturar Xuxemon
        Route::post('/capturar', 'store');

        // Mostrar todos los xuxemons capturados de x usuario
        Route::get('/capturados', 'showUser');

        // Dar chuches a un xuxemon capturado
        Route::post('/capturados/dar', 'giveCandy');

    });

    // MOCHILA
    Route::controller(MochilaController::class)->group(function () {

        // Get objetos en la mochila x usuario
        Route::get('/mochila', 'showAll');

        // Get chuches en la mochila x usuario
        Route::get('/mochila/candy', 'showCandies');

        // Get monedas en la mochila x usuario
        Route::get('/mochila/coins', 'showCoins');

        // Añadir chuches aleatorias a la mochila
        Route::post('/mochila/candy-debug', 'candyDebug');

        // Recompensa diaria
        Route::post('/redeem/daily-candy', 'dailyCandy');
    });

    // EQUIPO
    Route::controller(EquipoController::class)->group(function () {

        // Guardar xuxemon al equipo
        Route::post('/equipo', 'store');

        // Mostrar equipo
        Route::get('/equipo', 'show');

        // Quitar del equipo
        Route::delete('/equipo', 'destroy');

    });

    // ENFERMEDADES
    Route::controller(EnfermedadesController::class)->group(function () {

        // Mostrar enfermedades
        Route::get('/enfermedades', 'show');

    });

    // INFECTADOS
    Route::controller(InfectadosController::class)->group(function () {

        // Mostrar infectados
        Route::get('/infectados', 'showInfectados');

    });

    // FRIENDS
    Route::controller(FriendsController::class)->group(function () {

        // Buscar amigos
        Route::post('/friends/search', 'browseFriends');

        Route::post('/friends/add', 'addFriend');

        Route::get('/friends/show', 'showFriends');

        Route::get('/friends/request', 'showRequests');

        Route::post('/friends/accept', 'acceptFriend');

        Route::post('/friends/decline', 'declineFriendRequest');

        Route::delete('/friends/delete', 'deleteFriend');

    });

    // Usuario admin
    Route::middleware('CheckRole:admin')->group(function () {

        // XUXEMONS
        Route::controller(XuxemonsController::class)->group(function () {
            Route::post('/xuxemons', 'store');

            Route::put('/xuxemons/{xuxemons}', 'update');

            Route::delete('/xuxemons/{xuxemons}', 'destroy');
        });

        // Dar objetos en la mochila de x usuario
        Route::post('/mochila', [MochilaController::class, 'store']);

        // AJUSTES
        Route::controller(SettingsController::class)->group(function () {
            // Get default size
            Route::get('/settings/size', 'getDefaultSize');

            // Set default size
            Route::post('/settings/size', 'setDefaultSize');

            // Get medium candy
            Route::get('/settings/candy/medium', 'getMediumCandy');

            // Set medium candy
            Route::post('/settings/candy/medium', 'setMediumCandy');

            // Get big candy
            Route::get('/settings/candy/big', 'getBigCandy');

            // Set big candy
            Route::post('/settings/candy/big', 'setBigCandy');

            // Get daily candy
            Route::get('/settings/candy/daily', 'getDailyCandy');

            // Set daily candy
            Route::post('/settings/candy/daily', 'setDailyCandy');

            // Set percentage infecction
            Route::post('/settings/enfermedad/percentage', 'setPercentageInfection');

            // Get sugar low extra candy
            Route::get('/settings/sugar_low', 'getSugarLow');

            // Set sugar low extra candy
            Route::post('/settings/sugar_low', 'setSugarLow');
        });

        // INFECTADOS
        Route::controller(InfectadosController::class)->group(function () {

            // Infectar
            Route::post('/admin/infectar', 'infectarAdmin');

            // Curar
            Route::post('/admin/curar', 'curarAdmin');

            // Mostrar infectados
            Route::get('/admin/infectados', 'showInfectadosAdmin');

        });

        // CAPTURADOS
        Route::controller(CapturadosController::class)->group(function () {

            Route::get('/admin/capturados', 'showAll');

        });
    });


});
