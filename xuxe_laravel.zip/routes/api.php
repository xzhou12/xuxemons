<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\Controller;
use \App\Http\Controllers\XuxemonsController;
use App\Http\Controllers\CapturadosController;
use App\Http\Controllers\MochilaController;
use \App\Http\Controllers\SettingsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Registar
Route::post('/register', [Controller::class, 'register']);

// Loguearse
Route::post('/login', [Controller::class, 'login']);


// Middleware para verificar que el usuario esta logueado
Route::middleware('auth:sanctum')->group(function () {

    Route::controller(Controller::class)->group(function () {
        // Logout
        Route::post('/logout', 'logout');

        // Get role
        Route::get('/get-role', 'getRole');
    });


    Route::controller(XuxemonsController::class)->group(function () {

        // Mostrar todos los xuxemons
        Route::get('/xuxemons', 'show');

        // Mostrar un xuxemon
        Route::get('/xuxemons/{xuxemons}', 'showOne');

    });

    Route::controller(CapturadosController::class)->group(function () {

        // Capturar Xuxemon
        Route::post('/capturar', 'store');

        // Mostrar todos los xuxemons capturados de x usuario
        Route::get('/capturados', 'showUser');

        // Dar chuches a un xuxemon capturado
        Route::post('/capturados/dar', 'giveCandy');

    });

    Route::controller(MochilaController::class)->group(function () {

        // Get objetos en la mochila x usuario
        Route::get('/mochila', 'showAll');

        // Get chuches en la mochila x usuario
        Route::get('/mochila/candy', 'showCandies');

        // Get monedas en la mochila x usuario
        Route::get('/mochila/coins', 'showCoins');

        // Añadir chuches aleatorias a la mochila
        Route::post('/mochila/candy-debug', 'candyDebug');
    });

    // Usuario admin
    Route::middleware('CheckRole:admin')->group(function () {

        Route::controller(XuxemonsController::class)->group(function () {
            Route::post('/xuxemons', 'store');

            Route::put('/xuxemons/{xuxemons}', 'update');

            Route::delete('/xuxemons/{xuxemons}', 'destroy');
        });


        // Dar objetos en la mochila de x usuario
        Route::post('/mochila', [MochilaController::class, 'store']);

        Route::controller(SettingsController::class)->group(function () {
            // Get default size
            Route::get('/settings/size', 'getDefaultSize');

            // Set default size
            Route::post('/settings/size', 'setDefaultSize');

            // Get medium candy
            Route::get('/settings/candy/medium', 'getMediumCandy');

            // Set medium candy
            Route::post('/settings/candy/medium', 'setMediumCandy');

            // Get big candy
            Route::get('/settings/candy/big', 'getBigCandy');

            // Set big candy
            Route::post('/settings/candy/big', 'setBigCandy');
        });

    });

    // Usuario normal
    Route::middleware('CheckRole:user')->group(function () {
        // De momento nada
    });


});
