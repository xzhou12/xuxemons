<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use \App\Http\Controllers\Controller;
use \App\Http\Controllers\XuxemonsController;
use App\Http\Controllers\CapturadosController;
use App\Http\Controllers\MochilaController;
use \App\Http\Controllers\SettingsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Registar
Route::post('/register', [Controller::class, 'register']);

// Loguearse
Route::post('/login', [Controller::class, 'login']);

// Middleware para verificar que el usuario esta logueado
Route::middleware('auth:sanctum')->group(function () {

    // Logout
    Route::post('/logout', [Controller::class, 'logout']);

    // Mostrar todos los xuxemons
    Route::get('/xuxemons', [XuxemonsController::class, 'show']);

    // Mostrar un xuxemon
    Route::get('/xuxemons/{xuxemons}', [XuxemonsController::class, 'showOne']);

    /**
     * DE AQUI PARA ABAJO ES NUEVO
     */

    // Capturar Xuxemon
    Route::post('/capturar', [CapturadosController::class, 'store']);

    // Mostrar todos los xuxemons capturados de x usuario
    Route::get('/capturados', [CapturadosController::class, 'showUser']);

    // Dar chuches a un xuxemon capturado
    Route::post('/capturados/dar', [CapturadosController::class, 'giveCandy']);

    // Get objetos en la mochila x usuario
    Route::get('/mochila', [MochilaController::class, 'showAll']);

    // Get chuches en la mochila x usuario
    Route::get('/mochila/candy', [MochilaController::class, 'showCandies']);

    // Get monedas en la mochila x usuario
    Route::get('/mochila/coins', [MochilaController::class, 'showCoins']);

    // Añadir chuches aleatorias a la mochila
    Route::post('/mochila/candy-debug', [MochilaController::class, 'candyDebug']);

    // Usuario admin
    Route::middleware('CheckRole:admin')->group(function () {

        // Crear xuxemon
        Route::post('/xuxemons', [XuxemonsController::class, 'store']);

        // Actualizar xuxemon
        Route::put('/xuxemons/{xuxemons}', [XuxemonsController::class, 'update']);

        // Eliminar un xuxemon
        Route::delete('/xuxemons/{xuxemons}', [XuxemonsController::class, 'destroy']);

        /**
         * ESTO ES NUEVO
         */

        // Dar objetos en la mochila de x usuario
        Route::post('/mochila', [MochilaController::class, 'store']);

        Route::controller(SettingsController::class)->group(function () {
            // Get default size
            Route::get('/settings/size', 'getDefaultSize');

            // Set default size
            Route::post('/settings/size', 'setDefaultSize');

            // Get medium candy
            Route::get('/settings/candy/medium', 'getMediumCandy');

            // Set medium candy
            Route::post('/settings/candy/medium', 'setMediumCandy');

            // Get big candy
            Route::get('/settings/candy/big', 'getBigCandy');

            // Set big candy
            Route::post('/settings/candy/big', 'setBigCandy');
        });

        /*
        // Get default size
        Route::get('/settings/size', [SettingsController::class, 'getDefaultSize']);

        // Set default size
        Route::post('/settings/size', [SettingsController::class, 'setDefaultSize']);

        // Get medium candy
        Route::get('/settings/candy/medium', [SettingsController::class, 'getMediumCandy']);

        // Set medium candy
        Route::post('/settings/candy/medium', [SettingsController::class, 'setMediumCandy']);

        // Get big candy
        Route::get('/settings/candy/big', [SettingsController::class, 'getBigCandy']);

        // Set big candy
        Route::post('/settings/candy/big', [SettingsController::class, 'setBigCandy']);
        */
    });

    // Usuario normal
    Route::middleware('CheckRole:user')->group(function () {
        // De momento nada
    });
});
