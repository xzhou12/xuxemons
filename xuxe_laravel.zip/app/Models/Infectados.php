<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Infectados extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'capturados_id',
        'enfermedad_id',
    ];


    public function enfermedad() {
        return $this->belongsTo(Enfermedades::class);
    }

}
