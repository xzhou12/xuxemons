<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Capturados extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'xuxemon_id',
        'tamano',
        'caramelos_dados',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function xuxemon()
    {
        return $this->belongsTo(Xuxemons::class);
    }
}
