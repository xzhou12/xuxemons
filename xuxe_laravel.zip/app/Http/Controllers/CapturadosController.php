<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Enfermedades;
use App\Models\Infectados;
use App\Models\Mochila;
use App\Models\settings;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CapturadosController extends Controller
{

    /**
     * @param User $user
     * @return \Illuminate\Http\JsonResponse
     *
     * En funcion del token que se le pase, muestra todos los capturados
     * del usuario que haga referencia el token
     */
    public function showUser () {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los xuxemon capturados del usuario
            $capturados = Capturados::with('xuxemon')
                ->where('user_id', $user->id)
                ->get();

            // Retorna el resultado del select
            return response()->json($capturados);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Captura un xuxemon y lo guarda en la bbdd
     */
    public function store(Request $request) {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Si el usuario existe
            if (isset($user)) {
                // Se añade al request el campo de user_id
                $request->merge(['user_id' => $user->id]);
            }

            // Valida los datos
            $validados = $request->validate([
                'user_id' => ['required', 'exists:users,id'],
                'xuxemon_id' => ['required', 'exists:xuxemons,id'],
                'tamano' => ['in:small,medium,big'],
                'caramelos_dados' => ['numeric'],
            ]);

            // Hace el create con una transaccion
            DB::transaction(function () use ($validados) {
                Capturados::create($validados);
            });

            // Si ha ido bien, retorna un mensaje de que lo ha hecho bien
            return response()->json(['message' => 'Capturado de forma satisfactoria!'], 200);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al capturar: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Da caramelos al xuxemon capturado, cogiendo los caramelos de la mochila del usuario
     */
    public function giveCandy(Request $request) {
        try {

            // Valida los datos que se pasan
            $validados = $request->validate([
                'candy_id' => ['required', 'numeric', 'exists:mochilas,objetos_id'],
                'cantidad' => ['required', 'numeric', 'min:0'],
                'capturados_id' => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si el caramelo existe en la mochila del usuario
            $candy = Mochila::where('user_id', $user->id)
                ->where('objetos_id', $validados['candy_id'])
                // Y es de tipo caramelo
                ->whereHas('objetos', function ($query){
                    $query->where('tipo', 'candy');
                })
                ->get()->first();

            // Si existe
            if ($candy) {

                // Comprueba que la cantidad que se le quiere pasar por parametro es menor a la del stock
                if ($candy->cantidad >= $validados['cantidad']) {

                    // Comprueba que el xuxemon que le quieres dar un caramelo
                    $capturado = Capturados::where('user_id', $user->id)
                        // Lo tienes previamente capturado
                        ->where('id', $validados['capturados_id'])
                        ->get()->first();

                    if ($capturado) {

                        // Comprueba si el xuxemon tiene la enfermedad de atracón
                        $suger_binge = app(InfectadosController::class)->comprobarSugarBinge($user, $capturado);

                        if (!is_null($suger_binge)) {

                            // Comprueba si el caramelo es la cura de sugar binge
                            $enfermedad = Enfermedades::where('cod_enfermedad', 'sugar_binge')
                                ->get()->first();

                            // Si tiene la enfermedad y el caramelo no es la cura
                            if ($enfermedad->cura != $validados['candy_id']) {
                                // Devuelve que no se puede alimentar
                                return response()->json(['message' => 'El Xuxemon está de atracón, entonces no se puede alimentar'], 400);

                            }
                        }

                        // Transicion para dar caramelos al xuxemon y quitarlos de la mochila
                        DB::transaction(function () use ($candy, $capturado, $validados) {
                            $candy->decrement('cantidad', $validados['cantidad']);
                            $capturado->increment('caramelos_dados', $validados['cantidad']);
                        });

                        // Selecciona una enfermedad aleatoria
                        $enfermedad = Enfermedades::inRandomOrder()->first();

                        // Verifica si un numero aleatorio es menor al porcentaje
                        if (rand(1, 100) <= $enfermedad->porcentaje) {

                            // Comprueba si el xuxemon tiene dicha enfermedad
                            $infectado = Infectados::where('user_id', $user->id)
                                ->where('capturados_id', $capturado->id)
                                ->where('enfermedad_id', $enfermedad->id)
                                ->exists();

                            if (!$infectado) {
                                // Si no la tiene, procede a infectar
                                app(InfectadosController::class)->infectar($enfermedad, $user, $capturado);
                            }
                        }

                        // Comprueba la cantidad para que sea un xuxemon mediano
                        $medium_candy = settings::where('parametro', 'candy_medium')
                            ->get()->first();

                        // Comprueba la cantidad para que sea un xuxemon grande
                        $big_candy = settings::where('parametro', 'candy_big')
                            ->get()->first();

                        // Pasa los valores a int
                        $medium_candy = intval($medium_candy->valor);
                        $big_candy = intval($big_candy->valor) + $medium_candy;

                        // Comprueba si tiene la enfermedad de bajón de azucar
                        $sugar_low = app(InfectadosController::class)->comprobarSugarLow($user, $capturado);

                        if (!is_null($sugar_low)) {
                            // Si la tiene
                            $incremento = settings::where('parametro', 'sugar_low')
                                ->get()->first();

                            // Incrementa las chuches necesarias
                            $medium_candy += intval($incremento->valor);
                            $big_candy += intval($incremento->valor);
                        }

                        // Si tiene las suficientes
                        if ($capturado->caramelos_dados >= $big_candy) {
                            DB::transaction(function () use ($capturado) {
                                // Se cambia a grande
                                $capturado->update(['tamano' => 'big']);
                            });

                        } elseif ($capturado->caramelos_dados >= $medium_candy) {
                            DB::transaction(function () use ($capturado) {
                                // Se cambia a grande
                                $capturado->update(['tamano' => 'medium']);
                            });
                        }

                        // Comprueba si el caramelo es la cura de alguna enfermedad
                        $enfermedad = Enfermedades::where('cura', $validados['candy_id'])
                            ->get()->first();

                        if (!is_null($enfermedad)) {

                            // Comprueba si el xuxemon tiene dicha enfermedad
                            $infectado = app(InfectadosController::class)->comprobarInfectado($user, $capturado, $enfermedad);

                            // Si la tiene
                            if (!is_null($infectado)) {

                                // La cura
                                DB::transaction(function () use ($infectado) {
                                    $infectado->delete();
                                });
                            }
                        }

                        // Mensaje de ejeccución satisfactoria!
                        return response()->json(['message' => 'Se ha dado el caramelo de forma satisfactoria!'], 200);

                    } else {
                        // Si no está capturado, muestra un mensaje de errorr
                        return response()->json(['message' => 'El xuxemon no está registrado en tu xuxedex'], 400);
                    }
                } else {
                    // Si es mayor a la cantidad en stock, manda un mensaje de error
                    return response()->json(['message' => 'No tienes suficiente cantidad en tu mochila'], 400);
                }
            } else {
                // Si el caramelo no existe, manda un mensaje de error
                return response()->json(['message' => 'El caramelo no existe en tu mochila'], 400);
            }

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al dar caramelos: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Http\JsonResponse
     *
     * Retorna todos los capturados de todos los usuarios
     */
    public function showAll () {
        try {

            // Hace un select
            $capturados = Capturados::all();

            // Retorna el resultado
            return $capturados;

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }
}
