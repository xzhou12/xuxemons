<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Mochila;
use App\Models\Objetos;
use App\Models\settings;
use App\Models\User;
use App\Models\Xuxemons;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CapturadosController extends Controller
{

    /**
     * @param User $user
     * @return \Illuminate\Http\JsonResponse
     *
     * En funcion del token que se le pase, muestra todos los capturados
     * del usuario que haga referencia el token
     */
    public function showUser () {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los xuxemon capturados del usuario
            $capturados = Capturados::with('xuxemon')
                ->where('user_id', $user->id)
                ->get();

            // Retorna el resultado del select
            return response()->json($capturados);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Captura un xuxemon y lo guarda en la bbdd
     */
    public function store(Request $request) {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Si el usuario existe
            if (isset($user)) {
                // Se añade al request el campo de user_id
                $request->merge(['user_id' => $user->id]);
            }

            // Valida los datos
            $validados = $request->validate([
                'user_id' => ['required', 'exists:users,id'],
                'xuxemon_id' => ['required', 'exists:xuxemons,id'],
                'tamano' => ['in:small,medium,big'],
                'caramelos_dados' => ['numeric'],
            ]);

            // Hace el create con una transaccion
            DB::transaction(function () use ($validados) {
                Capturados::create($validados);
            });

            // Si ha ido bien, retorna un mensaje de que lo ha hecho bien
            return response()->json(['message' => 'Capturado de forma satisfactoria!'], 200);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al capturar: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Da caramelos al xuxemon capturado, cogiendo los caramelos de la mochila del usuario
     */
    public function giveCandy(Request $request) {
        try {

            // Valida los datos que se pasan
            $validados = $request->validate([
                'candy_id' => ['required', 'numeric', 'exists:mochilas,objetos_id'],
                'cantidad' => ['required', 'numeric', 'min:0'],
                'capturados_id' => ['required', 'exists:capturados,xuxemon_id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si el caramelo existe en la mochila del usuario
            $candy = Mochila::where('user_id', $user->id)
                ->where('objetos_id', $validados['candy_id'])
                // Y es de tipo caramelo
                ->whereHas('objetos', function ($query){
                    $query->where('tipo', 'candy');
                })
                ->get()->first();

            // Si existe
            if ($candy) {

                // Comprueba que la cantidad que se le quiere pasar por parametro es menor a la del stock
                if ($candy->cantidad >= $validados['cantidad']) {

                    // Comprueba que el xuxemon que le quieres dar un caramelo
                    $capturado = Capturados::where('user_id', $user->id)
                        // Lo tienes previamente capturado
                        ->where('xuxemon_id', $validados['capturados_id'])
                        ->get()->first();

                    if ($capturado) {

                        // Transicion para dar caramelos al xuxemon y quitarlos de la mochila
                        DB::transaction(function () use ($candy, $capturado, $validados) {
                            $candy->decrement('cantidad', $validados['cantidad']);
                            $capturado->increment('caramelos_dados', $validados['cantidad']);
                        });

                        // Comprueba la cantidad para que sea un xuxemon mediano
                        $medium_candy = settings::where('parametro', 'candy_medium')
                            ->get()->first();

                        $medium_candy = intval($medium_candy->valor);

                        // Si tiene más chuches dadas
                        if ($capturado->caramelos_dados >= $medium_candy) {

                            // Comprueba la cantidad para que sea un xuxemon grande
                            $big_candy = settings::where('parametro', 'candy_big')
                                ->get()->first();

                            $big_candy = intval($big_candy->valor);

                            // Si tiene las suficientes
                            if ($capturado->caramelos_dados >= $big_candy) {
                                DB::transaction(function () use ($capturado) {
                                    // Se cambia a grande
                                    $capturado->update(['tamano' => 'big']);
                                });
                            } else {
                                DB::transaction(function () use ($capturado) {
                                    // Si no, se cambia a mediano
                                    $capturado->update(['tamano' => 'medium']);
                                });
                            }
                        }

                        // Mensaje de ejeccución satisfactoria!
                        return response()->json(['message' => 'Se ha dado el caramelo de forma satisfactoria!'], 200);

                    } else {
                        // Si no está capturado, muestra un mensaje de errorr
                        return response()->json(['message' => 'El xuxemon no está registrado en tu xuxedex'], 400);
                    }
                } else {
                    // Si es mayor a la cantidad en stock, manda un mensaje de error
                    return response()->json(['message' => 'No tienes suficiente cantidad en tu mochila'], 400);
                }
            } else {
                // Si el caramelo no existe, manda un mensaje de error
                return response()->json(['message' => 'El caramelo no existe en tu mochila'], 400);
            }

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al dar caramelos: ' . $e->getMessage()], 500);
        }
    }
}
