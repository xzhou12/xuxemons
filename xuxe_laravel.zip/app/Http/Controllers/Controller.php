<?php

namespace App\Http\Controllers;

use App\Models\User;
use \Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Mockery\Exception;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    /**
     * Registro de los usuarios
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request) {

        try {
            // Valida los datos
            $validados = $request->validate([
                'name' => ['required', 'min:3', 'max:255'],
                'email' => ['required', 'max:255', 'unique:users'],
                'password' => ['required', 'min:3', 'max:255', 'confirmed'],
                'rol' => ['required', 'in:admin,user'],
            ]);

            $validados['id_code'] = '';
            for ($i = 0; $i < 4; $i++) {
                $validados['id_code'] .= strval(rand(1, 9));
            }

            // Crea el usuario
            DB::transaction(function () use ($validados) {
                User::create($validados);
            });

            // Devuelve un 200 (OK) para confirmar al usuario
            return response()->json(['message' => 'Usuario registrado correctamente'], 200);
        } catch (\Exception $e) {
            // Si hay algun fallo, hace un rollback y devuelve un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al registrar el usuario: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Login de los usuarios
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request) {

        try {
            // Valida los datos
            $validados = $request->validate([
                'email' => ['required', 'max:255', 'exists:users'],
                'password' => ['required', 'min:3', 'max:255'],
            ]);

            // Hace el intento de iniciar sesión
            if (Auth::attempt($validados)) {

                // Si las credenciales son correctas
                $user = Auth::user();
                $token = $user->createToken('authToken')->plainTextToken;

                // Deuvelve el token de acceso y el tipo de token
                return response()->json([
                    'access_token' => $token,
                    'token_type' => 'bearer',
                ], 200);
            } else {
                // Si no, deuvelve credenciales incorrectas
                return response()->json(['message' => 'Credenciales incorrectas'], 401);
            }

        } catch (\Exception $e) {
            // Si existe algun error, se muestras
            return response()->json(['message' => 'Ha ocurrido un error al hacer login: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Cerrar sesión del usuario
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout() {

        try {
            // Busca el usuario
            $user = Auth::guard('sanctum')->user();

            if ($user) {
                // Y elimina el token de acceso del usuario
                $user->currentAccessToken()->delete();

                // Devuelve un OK
                return response()->json(['message' => 'Se ha cerrado la sesión de forma satisfactoria'], 200);
            } else {
                // Si no se ha podido encontrar el usuario
                return response()->json(['message' => 'User not found'], 404);
            }

        } catch (\Exception $e) {
            // Si hay algun error se muestra
            return response()->json(['message' => 'Ha ocurrido un error al hacer logout: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Retorna el rol del usuario
     */
    public function getRole() {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            if ($user) {
                // Y devuelve el rol
                return response()->json($user->rol, 200);
            } else {
                // Si no se ha podido encontrar el usuario
                return response()->json(['message' => 'User not found'], 404);
            }

        } catch (\Exception $e) {
            // Si hay algun error se muestra
            return response()->json(['message' => 'Ha ocurrido un error al hacer logout: ' . $e->getMessage()], 500);
        }

    }

}
