<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Enfermedades;
use App\Models\settings;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SettingsController extends Controller
{
    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra el tamaño por defecto de los xuxemons capturados
     */
    public function getDefaultSize()
    {
        try {
            // Hace el select de la base de datos
            $default_size = settings::where('parametro', 'default_size')
                            ->first();

            // Y retorna el resultado
            return response()->json($default_size->valor, 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia el tamaño por defecto de los xuxemons
     */
    public function setDefaultSize(Request $request)
    {
        try {
            // Valida los datos
            $validado = $request->validate([
                'valor' => ['required', 'in:small,medium,big']
            ]);

            // Hace el select de la base de datos
            $default_size = settings::where('parametro', 'default_size')
                ->first();


            if ($default_size) {
                DB::transaction(function () use ($default_size, $validado) {
                    // Hace un update del valor por defecto
                    $default_size->update(['valor' => $validado['valor']]);
                });

            } else {
                // Si no, devuelve error
                return response()->json(['message' => 'No se ha podido hacer el insert!'], 500);
            }

            // Si lo ha hecho bien, devuelve un mensaje de confirmación
            return response()->json(['message' => 'Se ha modificado correctamente!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al actualizar la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Devuelve los caramelos necesarios para subir a nivel mediano
     */
    public function getMediumCandy()
    {
        try {
            // Selecciona de la bbdd la configuración
            $medium_candy = settings::where('parametro', 'candy_medium')
                ->first();

            // Retorna el valor
            return response()->json($medium_candy->valor, 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia el valor por defecto de los caramelos necesarios
     */
    public function setMediumCandy(Request $request)
    {
        try {
            // Valida los datos
            $validado = $request->validate([
                'valor' => ['required', 'numeric', 'min:1']
            ]);

            // Selecciona la cantidad para evolucionar a grande
            $big_candy = settings::where('parametro', 'candy_big')
                ->first();

            // Comprobar que sea menor que big_candy
            if ($big_candy && $validado['valor'] < $big_candy->valor) {

                // Selecciona en la base de datos
                $medium_candy = settings::where('parametro', 'candy_medium')
                    ->first();

                if ($medium_candy) {
                    // Hace el update con el nuevo valor
                    DB::transaction(function () use ($medium_candy, $validado) {
                        $medium_candy->update(['valor' => $validado['valor']]);
                    });

                    // llama la funcion para actualizar todos los valores
                    $this->updateCapturados();

                } else {
                    return response()->json(['message' => 'No se ha podido hacer actualizar el valor!'], 500);

                }

            } else {
                // Si es mayor, dice que no puede ser mayor
                return response()->json(['message' => 'El valor no puede ser superior al big: ' . $big_candy->valor], 500);
            }

            // Si se ha podido, manda un mensaje de confirmación
            return response()->json(['message' => 'Se ha modificado correctamente!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al actualizar la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Devuelve los caramelos necesarios para subir a nivel grande
     */
    public function getBigCandy()
    {
        try {

            // Selecciona de la bbdd la configuración
            $big_candy = settings::where('parametro', 'candy_big')
                ->first();

            // Retorna el valor
            return response()->json($big_candy->valor, 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia el valor por defecto de los caramelos necesarios
     */
    public function setBigCandy(Request $request)
    {
        try {
            // Valida los datos
            $validado = $request->validate([
                'valor' => ['required', 'numeric', 'min:1']
            ]);

            // Selecciona los caramelos necesarios para subir a mediano
            $medium_candy = settings::where('parametro', 'candy_medium')
                ->first();

            // Comprobar que sea mayor que medium candy
            if ($medium_candy && $validado['valor'] > $medium_candy->valor) {

                // Selecciona el parametro de big_candy
                $big_candy = settings::where('parametro', 'candy_big')
                    ->first();

                if ($big_candy) {
                    // Hace el update del valor por el nuevo
                    DB::transaction(function () use ($big_candy, $validado) {
                        $big_candy->update(['valor' => $validado['valor']]);
                    });

                    // llama la funcion para actualizar todos los valores
                    $this->updateCapturados();

                } else {
                    return response()->json(['message' => 'No se ha podido hacer actualizar el valor!'], 500);
                }

            } else {
                // Si es menor, dice que no puede ser menor
                return response()->json(['message' => 'El valor no puede ser inferior al mediano: ' . $medium_candy->valor], 500);
            }

            // Muestra un mensaje de confirmación
            return response()->json(['message' => 'Se ha modificado correctamente!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al actualizar la info: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @return void
     *
     * Actualiza todos los capturados afectados por la cantidad de
     * chuches necesarias para actualizar el nivel
     */
    public function updateCapturados() {

        // Selecciona los caramelos necesarios para subir a mediano
        $medium_candy = settings::where('parametro', 'candy_medium')
            ->first();

        // Selecciona el parametro de big_candy y medium_candy
        $big_candy = settings::where('parametro', 'candy_big')
            ->first();

        // Selecciona todos los pequeños, medianos y grandes
        $small = Capturados::where('caramelos_dados', '<', $medium_candy->valor)->get();

        $medium = Capturados::where('caramelos_dados', '<', ($big_candy->valor + $medium_candy->valor))
            ->where('caramelos_dados', '>=', $medium_candy->valor)->get();

        $big = Capturados::where('caramelos_dados', '>=', ($big_candy->valor + $medium_candy->valor))->get();

        // Y los va actualizando dependiendo de su sector
        foreach ($small as $cap_small) {

            DB::transaction(function () use ($cap_small) {
                $cap_small->update(['tamano' => 'small']);
            });
        }

        foreach ($medium as $cap_medium) {
            DB::transaction(function () use ($cap_medium) {
                $cap_medium->update(['tamano' => 'medium']);
            });
        }

        foreach ($big as $cap_big) {
            DB::transaction(function () use ($cap_big) {
                $cap_big->update(['tamano' => 'big']);
            });
        }

    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Retorna la cantidad de chuches diarias que
     * puede canjear el jugador
     */
    public function getDailyCandy() {

        try {

            // Selecciona de la bbdd la configuración
            $daily = settings::where('parametro', 'daily_candy')
                ->first();

            // Retorna el valor
            return response()->json($daily->valor, 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }

    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia la cantidad de chuches diarias que puede
     * canjear el jugador
     */
    public function setDailyCandy(Request $request) {

        try {
            // Valida los datos
            $validado = $request->validate([
                'valor' => ['required', 'numeric', 'min:1']
            ]);

            // Selecciona los caramelos necesarios para subir a mediano
            $daily = settings::where('parametro', 'daily_candy')
                ->first();

            // Hace el update del valor por el nuevo
            DB::transaction(function () use ($daily, $validado) {
                $daily->update(['valor' => $validado['valor']]);
            });

            // Muestra un mensaje de confirmación
            return response()->json(['message' => 'Se ha modificado correctamente!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al actualizar la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia el porcentaje de infección de las enfermedades
     *
     */
    public function setPercentageInfection(Request $request) {

        try {

            // Valida los datos
            $validados = $request->validate([
                'id_enfermedad' => ['required', 'numeric', 'exists:enfermedades,id'],
                'porcentaje' => ['required', 'numeric', 'min:0', 'max:100']
            ]);

            // Llama a la enfermedad
            $enfermedad = Enfermedades::where('id', $validados['id_enfermedad'])->first();


            DB::transaction(function () use ($enfermedad, $validados) {
                // Actualiza el valor por el nuevo
                $enfermedad->update(['porcentaje' => $validados['porcentaje']]);

            });

            // Devuelve un mensaje de OK
            return response()->json(['message' => 'Se ha actualizado de forma correcta!'], 200);

        } catch (\Exception $e) {
            // Si hay algún error, muestra el error
            return response()->json(['message' => 'Ha ocurrido un error al actualizar la info: ' . $e->getMessage()], 500);

        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las chuches adicionales que necesita
     * cuando tiene la enfermedad de bajón de azucar
     */
    public function getSugarLow () {

        try {

            // Retorna directamente el valor del query
            return settings::where('parametro', 'sugar_low')
                ->first()->valor;

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cambia las chuches adicionales que necesita
     * cuando tiene la enfermedad de bajón de azucar
     */
    public function setSugarLow (Request $request) {

        try {

            // Valida los datos
            $validados = $request->validate([
                'valor' => ['required', 'numeric', 'min:0']
            ]);

            // Llama al parametro en la base de datos
            $sugar_low = settings::where('parametro', 'sugar_low')
                ->first();

            DB::transaction(function () use ($validados, $sugar_low) {
                // Y actualiza los valores
                $sugar_low->update(['valor' => $validados['valor']]);
            });

            // Muestra un mensaje de confirmación
            return response()->json(['message' => 'Se ha modificado correctamente!'], 200);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

}
