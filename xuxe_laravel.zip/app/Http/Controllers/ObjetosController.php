<?php

namespace App\Http\Controllers;

use App\Models\Objetos;
use Illuminate\Http\Request;

class ObjetosController extends Controller
{

}
