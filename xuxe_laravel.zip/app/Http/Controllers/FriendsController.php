<?php

namespace App\Http\Controllers;

use App\Models\Friends;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class FriendsController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Busca amigos para enviar solicitud
     */
    public function browseFriends(Request $request)
    {
        try {
            // Valida los datos
            $request->validate([
                'name' => ['required', 'string', 'max:255'],
            ]);

            // Comprueba la sintaxis de la busqueda
            if (str_contains($request->name, '#')) {
                $name = explode('#', $request->name);

                // Busca al usuario
                $user = User::where('name', $name[0])
                    ->where('id_code', $name[1])
                    ->get();

                // Devuelve el usuario
                return $user;

            } else {
                // No contiene # en la petición
                return response()->json(['message' => 'Error de sintaxis'], 400);
            }

        } catch (Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Envia solicitud de amistad al usuario
     */
    public function addFriend(Request $request)
    {
        try {

            // Valida los datos
            $request->validate([
                'user_id' => ['required', 'integer', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si ya son amigos
            if ($user->isFriends->contains($request->user_id) ||
                $user->isFriends_r->contains($request->user_id)) {
                return response()->json(['message' => 'Ya sois amigos!'], 400);
            }

            // Verifica si ya se ha enviado una petición anteiormente
            if ($user->pedingRequest->contains($request->user_id)) {
                return response()->json(['message' => 'Ya has enviado una solicitud de amistad'], 400);
            }

            // Verifica si el usuario autenticado está intentando agregarse a sí mismo
            if ($request->user_id == $user->id) {
                return response()->json(['message' => 'No puedes añadirte a ti mismo'], 400);
            }

            // Envia la solicitud de amistad
            DB::transaction(function () use ($user, $request) {
                $user->friends()->attach($request->user_id);
            });

            // Devuelve un mensaje de respuesta
            return response()->json(['message' => 'Solicitud de amistad enviada correctamente'], 200);
        } catch (Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra la lista de amigos que tiene el usuario
     */
    public function showFriends()
    {
        try {

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Devuelve el resultado de dos eloquents
            return $user->isFriends->merge($user->isFriends_r);

        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las solicitudes entrantes del usuario
     */
    public function showRequests()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Devuelve un eloquent desde el modelo
            return $user->friendsRequest;

        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Acepta la solictud de amistad
     */
    public function acceptFriend(Request $request)
    {
        try {

            // Valida los datos
            $request->validate([
                'user_id' => ['required', 'integer', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si tiene una solicitud entrante del id del usuario
            if ($user->friendsRequest->contains($request->user_id)) {

                // Selecciona la solicitud
                $friend_request = Friends::where('user_id', $request->user_id)
                    ->where('friend_id', $user->id)->get()->first();

                // Actualiza la columna 'is_friend'
                DB::transaction(function () use ($friend_request) {
                    $friend_request->update(['is_friend' => true]);
                });

                // Devuelve un mensaje de confirmación
                return response()->json(['message' => 'Solicitud de amistad aceptada!'], 200);
            } else {
                return response()->json(['message' => 'No hay solicitud de este usuario'], 400);
            }
        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Rechaza la solicitud de amistad
     */
    public function declineFriendRequest(Request $request) {
        try {

            // Valida los datos
            $request->validate([
                'user_id' => ['required', 'integer', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba que el usuario le haya enviado una solicitud
            if ($user->friendsRequest->contains($request->user_id)) {

                // Selecciona la solictud
                $friend_request = Friends::where('user_id', $request->user_id)
                    ->where('friend_id', $user->id)->get()->first();

                // Y la borra
                DB::transaction(function () use ($friend_request) {
                    $friend_request->delete();
                });

                // Devuelve un mensaje de confirmación
                return response()->json(['message' => 'Solicitud de amistad rechazada :(!'], 200);

            } else {
                return response()->json(['message' => 'No hay solicitud de este usuario'], 400);
            }
        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Elimina un amigo añadido
     */
    public function deleteFriend(Request $request) {
        try {

            // Valida los datos
            $request->validate([
                'user_id' => ['required', 'integer', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si son amigos
            if ($user->isFriends->contains($request->user_id) ||
                $user->isFriends_r->contains($request->user_id)) {

                // Elimina los amigos
                DB::transaction(function () use ($user, $request) {
                    $user->friends()->detach($request->user_id);
                    User::find($request->user_id)->friends()->detach($user);
                });

                return response()->json(['message' => 'Una pena que ya no seais amigos :('], 200);

            } else {
                return response()->json(['message' => 'Este usuario no es tu amigo!!'], 400);
            }

        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

}
