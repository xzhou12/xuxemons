<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class EquipoController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda un xuxemon capturado en el equipo
     */
    public function store(Request $request) {

        try {

            // Valida que el id del capturado exista
            $validados = $request->validate([
                "capturado" => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Ahora comprueba si el capturado pertenece al usuario
            $capturado = Capturados::where('user_id', $user->id)
                ->where('id', $validados['capturado'])->get()->first();

            if (!is_null($capturado)) {

                // Comprueba que no tenga más de 4 en el equipo
                $registros = Capturados::where('user_id', $user->id)
                    ->where('equipado', true)->get();

                if (count($registros) < 4) {

                    // Comprueba que el xuxemon no esté en el equipo
                    if ($capturado->equipado == false) {
                        DB::transaction(function () use ($capturado) {
                            $capturado->update(['equipado' => true]);
                        });

                    } else {
                        // Si ya esta en el equipo
                        return response()->json(['message' => 'Ya está en el equipo!'], 401);
                    }

                    // Si se ha cargado correctamente, muestra un mensaje de confirmación
                    return response()->json(['message' => 'Xuxemon cargado en el equipo correctamente!'], 200);

                } else {
                    // Si se ha pasado el limite
                    return response()->json(['message' => 'Maximo 4 en el equipo!'], 400);
                }
            } else {
                return response()->json(['message' => 'El id del capturado no existe!'], 404);
            }

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al hacer el insert: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra el equipo del jugador
     */
    public function show() {
        try {

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los que pertencen al jugador
            $equipo = Capturados::with('xuxemon')
                ->where('user_id', $user->id)
                ->where('equipado', true)->get();

            return response()->json($equipo, 200);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al mostrar: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Equipo $equipo
     * @return \Illuminate\Http\JsonResponse
     *
     * Quita el xuxemon del equipo
     */
    public function destroy(Request $request) {
        try {

            $validados = $request->validate([
                'capturado' => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba si el id del capturado pertenece al usuario
            $capturado = Capturados::where('user_id', $user->id)
                ->where('id', $validados['capturado'])->get()->first();

            if (!is_null($capturado) && $capturado->equipado == true) {
                // Comprueba si el xuxemon tiene sobredosis de azúcar
                $suger_overdose = app(InfectadosController::class)
                    ->comprobarSugarOverdose($capturado->user_id, $capturado->id);

                if (is_null($suger_overdose)) {
                    // Si no tiene, procede a eliminarlo
                    DB::transaction(function () use ($capturado) {
                        $capturado->update(['equipado' => false]);
                    });

                    // Retorna borrado de forma correcta
                    return response()->json(['message' => 'Se ha borrado de forma correcta'], 200);
                } else {
                    // Si tiene, dice que no se puede quitar
                    return response()->json(['message' => 'El Xuxemon tiene una sobredosis de azucar, no se puede quitar en estos momentos'], 400);
                }
            } else {
                // Si no pertenece al usuario, muestra un mensaje de error
                return response()->json(['message' => 'El id del capturado no es tuyo o no esta equipado!'], 404);
            }
        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al quitar: ' . $e->getMessage()], 500);
        }
    }

}
