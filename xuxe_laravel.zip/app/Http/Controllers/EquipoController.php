<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Equipo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class EquipoController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda un xuxemon capturado en el equipo
     */
    public function store(Request $request) {

        try {

            // Valida que el id del capturado exista
            $validados = $request->validate([
                "capturado" => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Ahora comprueba si el capturado pertenece al usuario
            $existe = Capturados::where('user_id', $user->id)
                ->where('id', $validados['capturado'])->exists();

            if ($existe) {

                // Comprueba que no tenga más de 4 en el equipo
                $registros = Equipo::where('user_id', $user->id)->get();

                if (count($registros) < 4) {

                    // Comprueba que el xuxemon no esté en el equipo y se añada repetido
                    $existe = Equipo::where('user_id', $user->id)
                        ->where('capturados_id', $validados['capturado'])->exists();

                    if (!$existe) {
                        DB::transaction(function () use ($validados, $user) {

                            // Hace el insert en la bbdd
                            DB::table('equipos')->insert([
                                'user_id' => $user->id,
                                'capturados_id' => $validados['capturado'],
                            ]);
                        });

                    } else {
                        // Si ya esta en el equipo
                        return response()->json(['message' => 'Ya está en el equipo!'], 401);
                    }

                    // Si se ha cargado correctamente, muestra un mensaje de confirmación
                    return response()->json(['message' => 'Xuxemon cargado en el equipo correctamente!'], 200);

                } else {
                    // Si se ha pasado el limite
                    return response()->json(['message' => 'Maximo 4 en el equipo!'], 400);
                }
            } else {
                return response()->json(['message' => 'El id del capturado no existe!'], 404);
            }

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al hacer el insert: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra el equipo del jugador
     */
    public function show() {
        try {

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los que pertencen al jugador
            $equipo = Equipo::with('capturados')
                ->where('user_id', $user->id)->get();

            return response()->json($equipo, 200);

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al mostrar: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Equipo $equipo
     * @return \Illuminate\Http\JsonResponse
     *
     * Quita el xuxemon del equipo
     */
    public function destroy(Equipo $equipo) {
        try {

            // Comprueba si el xuxemon tiene sobredosis de azúcar
            $suger_overdose = app(InfectadosController::class)
                ->comprobarSugarOverdose($equipo->user_id, $equipo->capturados_id);

            if (is_null($suger_overdose)) {
                // Si no tiene, procede a eliminarlo

                DB::transaction(function () use ($equipo) {
                    $equipo->delete();
                });

                // Retorna borrado de forma correcta
                return response()->json(['message' => 'Se ha borrado de forma correcta'], 200);
            } else {
                // Si tiene, dice que no se puede quitar
                return response()->json(['message' => 'El Xuxemon tiene una sobredosis de azucar, no se puede quitar en estos momentos'], 400);
            }
        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al quitar: ' . $e->getMessage()], 500);
        }
    }

}
