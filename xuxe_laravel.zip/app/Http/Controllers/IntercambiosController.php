<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Infectados;
use App\Models\Intercambios;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class IntercambiosController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Ofrece un intercambio a un usuario amigo
     */
    public function ofrecerIntercambio(Request $request)
    {
        try {

            // Valida los datos que se pasan
            $validados = $request->validate([
                'reciver_id' => ['required', 'exists:users,id'],
                'offer_id' => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba que no se lo enviee a si mismo
            if (!$user->id != $validados['reciver_id']) {
                // Comprueba si a la persona que le ofrece, son amigos
                if ($user->isFriends->contains($validados['reciver_id']) ||
                    $user->isFriends_r->contains($validados['reciver_id'])) {

                    // Comprueba si ya hay una petición al usuario
                    $existe = Intercambios::where('sender_id', $user->id)
                        ->where('reciver_id', $validados['reciver_id'])
                        ->get()->first();

                    if (!is_null($existe)) {
                        return response()->json(['message' => 'Ya has enviado una petición a este usuario!'], 400);
                    }

                    // Comprueba si la oferta pertenece al usuario
                    $capturado = Capturados::where('user_id', $user->id)
                        ->where('id', $validados['offer_id'])
                        ->get()->first();

                    if (!is_null($capturado)) {

                        // Comprueba que el xuxemon no esté equiado
                        if ($capturado->equipado !== 0) {
                            return response()->json(['message' => 'No puedes intercambiar un xuxemon equipado'], 400);
                        }

                        $infectado = Infectados::where('user_id', $user->id)
                            ->where('capturados_id', $capturado->id)
                            ->get();

                        // Comprueba que el xuxemon no esté infectado
                        if (count($infectado) !== 0) {
                            return response()->json(['message' => 'No puedes intercambiar un xuxemon infectado!'], 400);
                        }

                        // Inserta la petición de intercambio a la bbdd
                        DB::transaction(function () use ($user, $validados) {
                            DB::table('intercambios')->insert([
                                'sender_id' => $user->id,
                                'reciver_id' => $validados['reciver_id'],
                                'offer_id' => $validados['offer_id']
                            ]);
                        });

                        // Envia un mensaje de confirmación
                        return response()->json(['message' => 'Se ha enviado la petición de intercambio de forma correcta!'], 200);

                    } else {
                        return response()->json(['message' => 'El id del capturado no pertenece a tus xuxemons'], 400);
                    }
                } else {
                    return response()->json(['message' => 'Este usuario no es tu amigo!'], 400);
                }
            } else {
                return response()->json(['message' => 'No puedes enviarte un xuxemon a ti mismo'], 400);
            }
        } catch (Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las ofertas que ha recibido el usuario
     */
    public function show()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            return Intercambios::where('reciver_id', $user->id)
                ->with('offer', 'sender')->get();

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Rechaza un intercambio
     */
    public function rechazarIntercambio(Request $request)
    {
        try {
            // Valida los datos
            $validados = $request->validate([
                'sender_id' => ['required', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba que no sean el mismo id de usuario
            if ($user->id != $validados['sender_id']) {
                // Comprueba si existe una petición de intercambio
                $existe = Intercambios::where('sender_id', $validados['sender_id'])
                    ->where('reciver_id', $user->id)
                    ->get()->first();

                // Si existe
                if (!is_null($existe)) {
                    // Elimina y rechaza la petición
                    DB::transaction(function () use ($existe) {
                        $existe->delete();
                    });

                    // Muestra un mensaje de confirmación
                    return response()->json(['message' => 'Has rechazado la solicitud de forma existosa!'], 200);
                } else {
                    return response()->json(['message' => 'No existe una oferta de intercambio por parte de este usuario'], 400);
                }
            } else {
                return response()->json(['message' => 'No puedes rechazarte a ti mismo!'], 400);
            }
        } catch (Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Acepta un intercambio
     */
    public function aceptarIntercambio(Request $request)
    {
        try {
            // Valida los datos
            $validados = $request->validate([
                'sender_id' => ['required', 'exists:users,id'],
                'offer_id' => ['required', 'exists:capturados,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Comprueba que el id de usuario no sea el mismo
            if ($user->id != $validados['sender_id']) {

                // Comprueba que exista un intercambio
                $intercambio = Intercambios::where('sender_id', $validados['sender_id'])
                    ->where('reciver_id', $user->id)
                    ->get()->first();

                if (!is_null($intercambio)) {

                    // Comprueba si el xuxemon ofrecido pertenece al usuario
                    $capturado = Capturados::where('user_id', $user->id)
                        ->where('id', $validados['offer_id'])
                        ->get()->first();

                    if (!is_null($capturado)) {

                        // Comprueba que el xuxemon no esté equiado
                        if ($capturado->equipado !== 0) {
                            return response()->json(['message' => 'No puedes intercambiar un xuxemon equipado'], 400);
                        }

                        $infectado = Infectados::where('user_id', $user->id)
                            ->where('capturados_id', $capturado->id)
                            ->get();

                        // Comprueba que el xuxemon no esté infectado
                        if (count($infectado) !== 0) {
                            return response()->json(['message' => 'No puedes intercambiar un xuxemon infectado!'], 400);
                        }

                        // Selecciona la oferta del otro usuario
                        $oferta = Capturados::where('user_id', $intercambio->sender_id)
                            ->where('id', $intercambio->offer_id)
                            ->get()->first();

                        DB::transaction(function () use ($intercambio, $capturado, $oferta, $user) {
                            // Cambia de usuario los xuxemons
                            $oferta->update(['user_id' => $user->id]);
                            $capturado->update(['user_id' => $intercambio->sender_id]);
                            // Y elimina la petición
                            $intercambio->delete();
                        });

                        // Devuelve un mensaje de confirmación
                        return response()->json(['message' => 'El intercambio se ha hecho de forma satisfactoria!'], 200);

                    } else {
                        return response()->json(['message' => 'El id del capturado no pertenece a tus xuxemons'], 400);
                    }
                } else {
                    return response()->json(['message' => 'No hay ofertas por parte de este usuario'], 400);
                }
            } else {
                return response()->json(['message' => 'No puedes aceptarte a ti mismo!'], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }
}
