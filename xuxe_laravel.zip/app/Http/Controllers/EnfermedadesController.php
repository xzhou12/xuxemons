<?php

namespace App\Http\Controllers;

use App\Models\Enfermedades;
use Illuminate\Http\Request;

class EnfermedadesController extends Controller
{

    /**
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Http\JsonResponse
     *
     * Muestra información de todas las enfermedades
     */
    public function show() {

        try {
            return Enfermedades::all();

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

}
