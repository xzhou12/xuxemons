<?php

namespace App\Http\Controllers;

use App\Models\settings;
use App\Models\Xuxemons;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class XuxemonsController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda un nuevo xuxemon a la base de datos
     */
    public function store(Request $request)
    {
        try {
            // Valida los datos
            $validados = $request->validate([
                'name' => ['required', 'min:3', 'max:100', 'unique:xuxemons'],
                'tipo' => ['required', 'in:Tierra,Aire,Agua'],
                'archivo' => ['required', 'min:3', 'max:100', 'unique:xuxemons'],
            ]);

            // Hace el select de la base de datos
            $validados['tamano'] = settings::where('parametro', 'default_size')
                ->first()->valor;

            DB::transaction(function () use ($validados) {
                // Crea los datos en una transaccion
                Xuxemons::create($validados);
            });

            // Devuelve un 200 (OK) para confirmar al usuario
            return response()->json(['message' => 'Xuxemon creado correctamente'], 200);
        } catch (\Exception $e) {

            // Y devuelve un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al crear el Xuxemon: ' . $e->getMessage()], 500);
        }

    }

    /**
     * @param Xuxemons $xuxemons
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra todos los xuxemons
     */
    public function show(Xuxemons $xuxemons)
    {
        try {
            // Selecciona todos los xuxemons
            $xuxemons = Xuxemons::all();
            // Retorna todos los xuxemons en forma json
            return response()->json(['xuxemons' => $xuxemons]);

        } catch (\Exception $e) {
            // Retorna error con el mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al retornar los xuxemons: ' . $e->getMessage()], 500);

        }
    }

    /**
     * @param Xuxemons $xuxemons
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra la información de 1 xuxemon
     */
    public function showOne (Xuxemons $xuxemons) {

        try {
            return response()->json(['xuxemons' => $xuxemons]);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al retornar los xuxemons: ' . $e->getMessage()], 500);
        }

    }


    /**
     * @param Request $request
     * @param Xuxemons $xuxemons
     * @return \Illuminate\Http\JsonResponse
     *
     * Actualiza la información de un xuxemon
     */
    public function update(Request $request, Xuxemons $xuxemons)
    {

        try {
            // Valida los datos
            $validados = $request->validate([
                'name' => ['required', 'min:3', 'max:100', 'unique:xuxemons,name,' . $xuxemons->id],
                'tipo' => ['required', 'in:Tierra,Aire,Agua'],
                'archivo' => ['required', 'min:3', 'max:100', 'unique:xuxemons,archivo,' . $xuxemons->id],
            ]);

            // Hace el update dentro de una transaccion
            DB::transaction(function () use ($validados, $xuxemons) {
                $xuxemons->update($validados);
            });

            // Retorna actualizado de forma satisfactoria
            return response()->json(['message' => 'Se ha actualizado de forma correcta'], 200);
        } catch (\Exception $e) {

            // Retorna error
            return response()->json(['message' => 'Ha ocurrido un error al actualizar los xuxemons: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Xuxemons $xuxemons
     * @return \Illuminate\Http\JsonResponse
     *
     * Elimina el xuxemon
     */
    public function destroy(Xuxemons $xuxemons)
    {
        try {
            // Hace una trasaccion para eliminar
            DB::transaction(function () use ($xuxemons) {
                $xuxemons->delete();
            });

            // Retorna borrado de forma correcta
            return response()->json(['message' => 'Se ha borrado de forma correcta'], 200);
        } catch (\Exception $e) {

            // Retorna error
            return response()->json(['message' => 'Ha ocurrido un error al eliminar: ' . $e->getMessage()], 500);
        }
    }
}
