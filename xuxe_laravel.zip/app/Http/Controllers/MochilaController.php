<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Mochila;
use App\Models\Objetos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MochilaController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda objetos en la mochila del usuario
     */
    public function store(Request $request)
    {
        try {
            // Valida los datos pasados por parametro
            $validados = $request->validate([
                'user_id' => ['required', 'exists:users,id'],
                'objetos_id' => ['required', 'exists:objetos,id'],
                'cantidad' => ['required', 'numeric']
            ]);

            // Comrpueba si el objeto que se quiere añadir existe en la mochila
            $mochila = Mochila::where('user_id', $validados['user_id'])
                ->where('objetos_id', $validados['objetos_id'])
                ->first();

            // Si existe
            if ($mochila) {
                // Se incrementa esa cantidad
                DB::transaction(function () use ($validados, $mochila) {
                    $mochila->increment('cantidad', $validados['cantidad']);
                });
            } else {
                // Si no, se crea
                DB::transaction(function () use ($validados) {
                    Mochila::create($validados);
                });
            }

            // Si ha ido bien, retorna un mensaje de confirmación
            return response()->json(['message' => 'Se ha añadido a la mochila de forma satisfacotria!'], 200);

        } catch (\Exception $e) {
            // Si ha fallado en algun punto, salta un mensaje de error
            return response()->json(['message' => 'Ha ocurrido al añadir el producto a la mochila: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Añade chuches aleatorias en la mochila del usuario
     */
    public function candyDebug()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los objetos de tipo chuche
            $candies = Objetos::all()->where('tipo', 'candy');
            $rand = rand(1, 10); // Genera un numero random del 1 al 10

            // Loop x veces
            for ($i = 0; $i < $rand; $i++) {

                DB::transaction(function () use ($candies, $user) {
                    // Selecciona un objeto aleatorio
                    $rand_objeto = $candies->random()->id;

                    // Comrpueba si el objeto que se quiere añadir existe en la mochila
                    $mochila = Mochila::where('user_id', $user->id)
                        ->where('objetos_id', $rand_objeto)
                        ->first();

                    // Si existe
                    if ($mochila) {
                        // Se incrementa esa cantidad
                        $mochila->increment('cantidad', rand(1, 10));
                    } else {
                        // Si no, se crea
                        DB::table('mochilas')->insert([
                            'user_id' => $user->id,
                            'objetos_id' => $rand_objeto,
                            'cantidad' => rand(1, 10),
                        ]);
                    }
                });
            }

            // Si se ha hecho el debug, muestra un mensaje de confirmación
            return response()->json(['message' => 'Se han añadido chuches de forma satisfactoria!'], 200);

        } catch (\Exception $e) {

            // Si peta, muestra un mensaje
            return response()->json(['message' => 'Ha ocurrido un error al hacer debug: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las chuches que lleva el usuario en la mochila
     */
    public function showCandies()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los objetos de tipo candy que tiene el usuario
            $mochila = Mochila::with('objetos')
                ->where('user_id', $user->id)
                ->whereHas('objetos', function ($query){
                    $query->where('tipo', 'candy');
                })
                ->get();

            // Retorna el resultado del select
            return response()->json($mochila);

        } catch (\Exception $e) {
            // Si ha ocurrido algun error, se muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra las monedas que lleva el usuario en la mochila
     */
    public function showCoins()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de las monedas que tiene el usuario en la mochila
            $mochila = Mochila::with('objetos')
                ->where('user_id', $user->id)
                ->whereHas('objetos', function ($query){
                    $query->where('tipo', 'monedas');
                })
                ->get();

            // Devuelve el resultado del select
            return response()->json($mochila);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra todo lo que tiene el usuario en la mochila
     */
    public function showAll()
    {
        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace el select de la mochila del usuario
            $mochila = Mochila::with('objetos')
                ->where('user_id', $user->id)
                ->get();

            // Devuelve el select
            return response()->json($mochila);

        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error al obtener la info: ' . $e->getMessage()], 500);
        }
    }
}
