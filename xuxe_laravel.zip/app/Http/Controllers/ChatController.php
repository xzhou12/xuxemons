<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Guarda el mensaje en la bbdd
     */
    public function store(Request $request) {
        try {

            // Valida los datos
            $validated = $request->validate([
                'user_id' => ['required', 'exists:users,id'],
                'message' => 'required',
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Valide que no le envie al mismo
            if ($user->id !== $validated['user_id']) {
                // Comprueba si el remitente, son amigos
                if ($user->isFriends->contains($validated['user_id']) ||
                    $user->isFriends_r->contains($validated['user_id'])) {

                    // Una vez comprobado
                    DB::transaction(function () use ($validated, $user) {

                        // Inserta a la bbdd el mensaje
                        DB::table('chats')->insert([
                            'user_id' => $user->id,
                            'friend_id' => $validated['user_id'],
                            'message' => $validated['message'],
                            'created_at' => now(),
                        ]);
                    });

                    return response()->json(['message' => 'El mensaje se ha enviado correctamente'], 200);

                } else {
                    return response()->json(['message' => 'Este usuario no es tu amigo!'], 400);
                }
            } else {
                return response()->json(['message' => 'No puedes enviarte mensajes a ti mismo!'], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Carga el chat con tu amigo
     */
    public function show(Request $request) {
        try {

            // Valida los datos
            $validated = $request->validate([
                'user_id' => ['required', 'exists:users,id'],
            ]);

            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Valide que no le envie al mismo
            if ($user->id != $validated['user_id']) {
                // Comprueba si el remitente, son amigos
                if ($user->isFriends->contains($validated['user_id']) ||
                    $user->isFriends_r->contains($validated['user_id'])) {

                    // Inner join chat usuario con receptor
                    /*
                    $chats = Chat::join('users as u1', function ($join) use ($user) {
                        $join->on('chats.user_id', '=', 'u1.id')
                            ->where('chats.user_id', '=', $user->id)
                            ->orWhere('chats.friend_id', '=', $user->id);
                    })
                        ->join('users as u2', function ($join) use ($validated) {
                            $join->on('chats.user_id', '=', 'u2.id')
                                ->where('chats.friend_id', '=', $validated['user_id'])
                                ->orWhere('chats.user_id', '=', $validated['user_id']);
                        })
                        ->orderBy('chats.created_at', 'desc')
                        ->with('user')
                        ->distinct()
                        ->take(10)
                        ->get(['chats.*']);
                    */
                    $chats = Chat::where(function ($query) use ($user, $validated) {
                        $query->where('user_id', $user->id)
                            ->orWhere('friend_id', $user->id);
                    })
                        ->where(function ($query) use ($user, $validated) {
                            $query->where('user_id', $validated['user_id'])
                                ->orWhere('friend_id', $validated['user_id']);
                        })
                        ->orderBy('created_at', 'desc')
                        ->with('user')
                        ->distinct()
                        ->take(10)
                        ->get();

                    return response()->json($chats, 200);

                } else {
                    return response()->json(['message' => 'Este usuario no es tu amigo!'], 400);
                }
            } else {
                return response()->json(['message' => 'No puedes ver los mensajes a de ti mismo!'], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }
}
