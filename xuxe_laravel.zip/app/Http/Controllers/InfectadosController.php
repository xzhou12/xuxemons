<?php

namespace App\Http\Controllers;

use App\Models\Capturados;
use App\Models\Infectados;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class InfectadosController extends Controller
{

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Infecta el xuxemon que se le pasa por parametro
     */
    public function infectarAdmin(Request $request) {
        try {

            // Valida los datos
            $validados = $request->validate([
                'capturados_id' => ['required', 'numeric', 'exists:capturados,id'],
                'enfermedad_id' => ['required', 'numeric', 'exists:enfermedades,id']
            ]);

            // Comprueba de que usuario pertenece el captturado
            $user = Capturados::where('id', $validados['capturados_id'])
                ->get()->first();

            // Comprueba que no esté infectado
            $exists = Infectados::where('user_id', $user->user_id)
                ->where('capturados_id', $validados['capturados_id'])
                ->where('enfermedad_id', $validados['enfermedad_id'])
                ->exists();

            if (!$exists) {

                // Infecta el xuxemon capturado
                DB::transaction(function () use ($user, $validados) {
                    DB::table('infectados')->insert([
                        'user_id' => $user->user_id,
                        'capturados_id' => $validados['capturados_id'],
                        'enfermedad_id' => $validados['enfermedad_id']
                    ]);
                });

                // Muestra un mensaje de satisfacción
                return response()->json(['message' => 'Se ha infectado correctamente!'], 200);

            } else {
                // Muestra un mensaje de que ya contiene dicha enfermedad
                return response()->json(['message' => 'El xuxemon ya tiene dicha infeccion'], 400);
            }
        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     *
     * Cura el xuxemon capturado que se le pasa por parametro
     */
    public function curarAdmin(Request $request) {
        try {

            // Valida los datos
            $validados = $request->validate([
                'infectado_id' => ['required', 'numeric', 'exists:infectados,id'],
            ]);

            // Hace un select del infectado
            $infectado = Infectados::where('id', $validados['infectado_id'])
                ->get()->first();

            if (!is_null($infectado)) {

                // Elimina el registro
                DB::transaction(function () use ($infectado) {
                    $infectado->delete();
                });

                // Muestra un mensaje de satistacción
                return response()->json(['message' => 'Se ha curado correctamente!'], 200);
            } else {
                return response()->json(['message' => 'El xuxemon infectado no existe'], 400);
            }
        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);

        }
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     *
     * Muestra los infectados del usuario
     */
    public function showInfectados() {

        try {
            // Comprueba si existe el token guardado en el sanctum
            if (!empty(Auth::guard('sanctum')->user())) {
                // Guarda el usuario
                $user = Auth::guard('sanctum')->user();
            }

            // Hace un select de todos los infectados del usuario
            $infectados = Infectados::where('user_id', $user->id)
                ->with('enfermedad')->get();

            return $infectados;

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * @return \Illuminate\Database\Eloquent\Collection|\Illuminate\Http\JsonResponse
     *
     * Muestra todos los infectados
     */
    public function showInfectadosAdmin() {
        try {

            // Retorna todos los infectados
            return Infectados::all();

        } catch (\Exception $e) {
            // Si ha dado error, muestra un mensaje de error
            return response()->json(['message' => 'Ha ocurrido un error: ' . $e->getMessage()], 500);
        }
    }


    /**
     * @param $enfermedad
     * @param $user
     * @param $capturado
     * @return void
     *
     * Infecta el xuxemon capturado con la enfermedad
     * que se le pasa por parametro
     */
    public function infectar($enfermedad, $user, $capturado) {
        DB::transaction(function () use ($enfermedad, $user, $capturado) {
            DB::table('infectados')->insert([
                'user_id' => $user->id,
                'capturados_id' => $capturado->id,
                'enfermedad_id' => $enfermedad->id
            ]);
        });
    }

    /**
     * @param $user
     * @param $capturado
     * @return mixed
     *
     * Comprueba si el xuxemon capturado que se le pasa
     * por parametro tiene la enfermedad bajón de azucar
     */
    public function comprobarSugarLow($user, $capturado) {

        return Infectados::where('user_id', $user->id)
            ->where('capturados_id', $capturado->id)
            ->whereHas('enfermedad', function ($query) {
                $query->where('cod_enfermedad', 'sugar_low');
            })
            ->get()->first();

    }

    /**
     * @param $user
     * @param $capturado
     * @return mixed
     *
     * Comprueba si el xuxemon capturado que se le pasa
     * por parametro tiene la enfermedad atracón
     */
    public function comprobarSugarBinge($user, $capturado) {

        return Infectados::where('user_id', $user->id)
            ->where('capturados_id', $capturado->id)
            ->whereHas('enfermedad', function ($query) {
                $query->where('cod_enfermedad', 'sugar_binge');
            })
            ->get()->first();

    }


    /**
     * @param $user
     * @param $capturado
     * @return mixed
     *
     * Comprueba si el xuxemon capturado que se le pasa
     * por parametro tiene la enfermedad sobredosis de azucar
     */
    public function comprobarSugarOverdose($user, $capturado)
    {

        return Infectados::where('user_id', $user)
            ->where('capturados_id', $capturado)
            ->whereHas('enfermedad', function ($query) {
                $query->where('cod_enfermedad', 'sugar_overdose');
            })
            ->get()->first();

    }


    /**
     * @param $user
     * @param $capturado
     * @param $enfermedad
     * @return mixed
     *
     * Comprueba si tiene la enfermedad que se le pasa
     * por parametro
     */
    public function comprobarInfectado($user, $capturado, $enfermedad)
    {

        return Infectados::where('user_id', $user->id)
            ->where('capturados_id', $capturado->id)
            ->where('enfermedad_id', $enfermedad->id)
            ->get()->first();

    }

}
